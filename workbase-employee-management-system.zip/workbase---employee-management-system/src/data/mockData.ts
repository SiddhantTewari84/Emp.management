import { Department, Employee, LeaveRequest, AttendanceRecord, PayrollRecord } from '../types/employee';

export const INITIAL_DEPARTMENTS: Department[] = [
  {
    id: 'dept-eng',
    name: 'Engineering',
    code: 'ENG',
    lead: 'Rohan Verma',
    budgetAnnual: 18000000,
    description: 'Core platform, cloud infrastructure, backend microservices, and client applications.'
  },
  {
    id: 'dept-prd',
    name: 'Product',
    code: 'PRD',
    lead: 'Ananya Sen',
    budgetAnnual: 8500000,
    description: 'Product roadmap, feature specifications, discovery, and customer feedback loops.'
  },
  {
    id: 'dept-dsn',
    name: 'Design & UX',
    code: 'DSN',
    lead: 'Kabir Mehta',
    budgetAnnual: 5500000,
    description: 'Design system, UX research, interaction design, and brand identity.'
  },
  {
    id: 'dept-mkt',
    name: 'Marketing & Growth',
    code: 'MKT',
    lead: 'Priya Nambiar',
    budgetAnnual: 6500000,
    description: 'Performance marketing, content strategy, brand communications, and lifecycle.'
  },
  {
    id: 'dept-ppl',
    name: 'People & Culture',
    code: 'PPL',
    lead: 'Sunita Rao',
    budgetAnnual: 4200000,
    description: 'Talent acquisition, employee experience, compensation policy, and payroll.'
  }
];

export const INITIAL_EMPLOYEES: Employee[] = [
  {
    id: 'emp-1001',
    employeeCode: 'EMP-1001',
    firstName: 'Rohan',
    lastName: 'Verma',
    email: 'rohan.verma@workbase.io',
    phone: '+91 98201 44512',
    role: 'VP of Engineering',
    department: 'Engineering',
    employmentType: 'Full-time',
    workMode: 'Hybrid',
    status: 'Active',
    joinDate: '2022-03-15',
    salaryAnnual: 4200000,
    location: 'Bengaluru, India',
    manager: 'CEO / Board',
    emergencyContact: {
      name: 'Meera Verma',
      relation: 'Spouse',
      phone: '+91 98201 44519'
    },
    bankInfo: {
      accountMasked: '•••• •••• 9214',
      bankName: 'HDFC Bank',
      ifscOrSwift: 'HDFC0001042'
    },
    leaveBalance: { annual: 16, casual: 6, sick: 9 },
    notes: 'Key architectural lead for microservices migration and technical steering.'
  },
  {
    id: 'emp-1002',
    employeeCode: 'EMP-1002',
    firstName: 'Ananya',
    lastName: 'Sen',
    email: 'ananya.sen@workbase.io',
    phone: '+91 98112 39011',
    role: 'Principal Product Manager',
    department: 'Product',
    employmentType: 'Full-time',
    workMode: 'On-site',
    status: 'Active',
    joinDate: '2022-06-01',
    salaryAnnual: 3400000,
    location: 'Bengaluru, India',
    manager: 'CEO / Board',
    emergencyContact: {
      name: 'Debashis Sen',
      relation: 'Father',
      phone: '+91 98112 39099'
    },
    bankInfo: {
      accountMasked: '•••• •••• 4421',
      bankName: 'ICICI Bank',
      ifscOrSwift: 'ICIC0000411'
    },
    leaveBalance: { annual: 12, casual: 4, sick: 10 },
    notes: 'Spearheading Q4 Enterprise tier launch and pricing tier realignment.'
  },
  {
    id: 'emp-1003',
    employeeCode: 'EMP-1003',
    firstName: 'Kabir',
    lastName: 'Mehta',
    email: 'kabir.mehta@workbase.io',
    phone: '+91 98450 78210',
    role: 'Head of Design',
    department: 'Design & UX',
    employmentType: 'Full-time',
    workMode: 'Remote',
    status: 'Active',
    joinDate: '2022-08-15',
    salaryAnnual: 3100000,
    location: 'Bengaluru, India',
    manager: 'CEO / Board',
    emergencyContact: {
      name: 'Sonia Mehta',
      relation: 'Spouse',
      phone: '+91 98450 78219'
    },
    bankInfo: {
      accountMasked: '•••• •••• 6554',
      bankName: 'HDFC Bank',
      ifscOrSwift: 'HDFC0000240'
    },
    leaveBalance: { annual: 18, casual: 7, sick: 12 },
    notes: 'Brand visual identity overseer and design critique lead.'
  },
  {
    id: 'emp-1004',
    employeeCode: 'EMP-1004',
    firstName: 'Priya',
    lastName: 'Nambiar',
    email: 'priya.nambiar@workbase.io',
    phone: '+91 98711 00234',
    role: 'Growth Marketing Lead',
    department: 'Marketing & Growth',
    employmentType: 'Full-time',
    workMode: 'Hybrid',
    status: 'On Leave',
    joinDate: '2023-02-01',
    salaryAnnual: 2500000,
    location: 'Mumbai, India',
    manager: 'CEO / Board',
    emergencyContact: {
      name: 'Karthik Nambiar',
      relation: 'Brother',
      phone: '+91 98711 00238'
    },
    bankInfo: {
      accountMasked: '•••• •••• 1928',
      bankName: 'State Bank of India',
      ifscOrSwift: 'SBIN0004012'
    },
    leaveBalance: { annual: 4, casual: 2, sick: 10 },
    notes: 'Currently on planned annual leave until end of the week.'
  },
  {
    id: 'emp-1005',
    employeeCode: 'EMP-1005',
    firstName: 'Sunita',
    lastName: 'Rao',
    email: 'sunita.rao@workbase.io',
    phone: '+91 99001 77821',
    role: 'Head of People Operations',
    department: 'People & Culture',
    employmentType: 'Full-time',
    workMode: 'On-site',
    status: 'Active',
    joinDate: '2022-04-01',
    salaryAnnual: 2700000,
    location: 'Bengaluru, India',
    manager: 'CEO / Board',
    emergencyContact: {
      name: 'Anand Rao',
      relation: 'Spouse',
      phone: '+91 99001 77829'
    },
    bankInfo: {
      accountMasked: '•••• •••• 5590',
      bankName: 'HDFC Bank',
      ifscOrSwift: 'HDFC0000541'
    },
    leaveBalance: { annual: 13, casual: 5, sick: 12 },
    notes: 'Responsible for employee onboarding, compliance, and workplace culture.'
  }
];

export const INITIAL_LEAVE_REQUESTS: LeaveRequest[] = [
  {
    id: 'lv-201',
    employeeId: 'emp-1004',
    employeeName: 'Priya Nambiar',
    employeeRole: 'Growth Marketing Lead',
    department: 'Marketing & Growth',
    type: 'Paid Annual',
    startDate: '2026-10-16',
    endDate: '2026-10-21',
    days: 4,
    reason: 'Family wedding ceremony and scheduled annual leave.',
    status: 'Approved',
    appliedDate: '2026-10-05',
    reviewedBy: 'Sunita Rao'
  },
  {
    id: 'lv-202',
    employeeId: 'emp-1002',
    employeeName: 'Ananya Sen',
    employeeRole: 'Principal Product Manager',
    department: 'Product',
    type: 'Sick',
    startDate: '2026-10-19',
    endDate: '2026-10-20',
    days: 2,
    reason: 'Seasonal viral fever; advised bed rest by physician.',
    status: 'Pending',
    appliedDate: '2026-10-18'
  },
  {
    id: 'lv-203',
    employeeId: 'emp-1003',
    employeeName: 'Kabir Mehta',
    employeeRole: 'Head of Design',
    department: 'Design & UX',
    type: 'Casual',
    startDate: '2026-10-24',
    endDate: '2026-10-24',
    days: 1,
    reason: 'Personal administrative work at municipal registry.',
    status: 'Pending',
    appliedDate: '2026-10-17'
  },
  {
    id: 'lv-204',
    employeeId: 'emp-1001',
    employeeName: 'Rohan Verma',
    employeeRole: 'VP of Engineering',
    department: 'Engineering',
    type: 'Paid Annual',
    startDate: '2026-11-04',
    endDate: '2026-11-08',
    days: 5,
    reason: 'Diwali festive trip with extended family.',
    status: 'Approved',
    appliedDate: '2026-10-12',
    reviewedBy: 'CEO / Board'
  }
];

export const INITIAL_ATTENDANCE: AttendanceRecord[] = [
  {
    id: 'att-01',
    employeeId: 'emp-1001',
    employeeName: 'Rohan Verma',
    date: '2026-10-18',
    status: 'Present',
    checkIn: '09:12 AM',
    checkOut: '06:45 PM',
    workHours: 9.5
  },
  {
    id: 'att-02',
    employeeId: 'emp-1002',
    employeeName: 'Ananya Sen',
    date: '2026-10-18',
    status: 'Present',
    checkIn: '09:28 AM',
    checkOut: '07:10 PM',
    workHours: 9.7
  },
  {
    id: 'att-03',
    employeeId: 'emp-1003',
    employeeName: 'Kabir Mehta',
    date: '2026-10-18',
    status: 'Remote',
    checkIn: '09:32 AM',
    checkOut: '06:50 PM',
    workHours: 9.3
  },
  {
    id: 'att-04',
    employeeId: 'emp-1004',
    employeeName: 'Priya Nambiar',
    date: '2026-10-18',
    status: 'On Leave'
  },
  {
    id: 'att-05',
    employeeId: 'emp-1005',
    employeeName: 'Sunita Rao',
    date: '2026-10-18',
    status: 'Present',
    checkIn: '09:15 AM',
    checkOut: '06:20 PM',
    workHours: 9.1
  }
];

export function generatePayrollRecords(employees: Employee[], month: string = 'October 2026'): PayrollRecord[] {
  return employees.map((emp) => {
    const monthlyGross = Math.round(emp.salaryAnnual / 12);
    const baseSalary = Math.round(monthlyGross * 0.50);
    const hra = Math.round(monthlyGross * 0.30);
    const allowances = Math.round(monthlyGross * 0.20);
    const deductions = Math.round(baseSalary * 0.12); // PF approx 12%
    const tax = Math.round(monthlyGross * 0.10); // Standard approx TDS
    const netPay = monthlyGross - deductions - tax;

    return {
      id: `pay-${emp.id}-${month.replace(' ', '-').toLowerCase()}`,
      employeeId: emp.id,
      employeeName: `${emp.firstName} ${emp.lastName}`,
      employeeCode: emp.employeeCode,
      role: emp.role,
      department: emp.department,
      month,
      baseSalary,
      hra,
      allowances,
      deductions,
      tax,
      netPay,
      status: emp.status === 'Inactive' ? 'Pending' : 'Paid',
      paymentDate: '2026-10-01'
    };
  });
}

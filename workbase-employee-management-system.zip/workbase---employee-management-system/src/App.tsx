import React, { useState, useEffect, useMemo } from 'react';
import { EmployeeProvider, useEmployees } from './context/EmployeeContext';
import { Sidebar, NavTab } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { EmployeeFilterBar } from './components/directory/EmployeeFilterBar';
import { EmployeeTable } from './components/directory/EmployeeTable';
import { EmployeeCardGrid } from './components/directory/EmployeeCardGrid';
import { EmployeeDetailModal } from './components/directory/EmployeeDetailModal';
import { EmployeeFormModal } from './components/directory/EmployeeFormModal';
import { DeleteConfirmModal } from './components/common/DeleteConfirmModal';
import { AttendanceView } from './components/attendance/AttendanceView';
import { DepartmentsView } from './components/departments/DepartmentsView';
import { PayrollView } from './components/payroll/PayrollView';
import { AnalyticsView } from './components/analytics/AnalyticsView';
import { Employee } from './types/employee';

function MainApp() {
  const { employees, departments, deleteEmployee } = useEmployees();

  // Navigation & Theme
  const [activeTab, setActiveTab] = useState<NavTab>('directory');
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [isDark, setIsDark] = useState<boolean>(() => {
    return localStorage.getItem('workbase_theme') === 'dark';
  });

  // Apply dark mode class to root HTML
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('workbase_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('workbase_theme', 'light');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark(prev => !prev);

  // Directory Filters & View State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedWorkMode, setSelectedWorkMode] = useState('all');
  const [viewMode, setViewMode] = useState<'table' | 'grid'>(() =>
    typeof window !== 'undefined' && window.innerWidth < 1024 ? 'grid' : 'table'
  );

  // Sorting
  const [sortField, setSortField] = useState<keyof Employee>('firstName');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Modals
  const [viewingEmployee, setViewingEmployee] = useState<Employee | null>(null);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [deletingEmployee, setDeletingEmployee] = useState<Employee | null>(null);

  const handleToggleSort = (field: keyof Employee) => {
    if (sortField === field) {
      setSortDirection(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Filtered & Sorted Employees
  const filteredEmployees = useMemo(() => {
    let result = [...employees];

    // Global Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(emp =>
        emp.firstName.toLowerCase().includes(q) ||
        emp.lastName.toLowerCase().includes(q) ||
        emp.email.toLowerCase().includes(q) ||
        emp.employeeCode.toLowerCase().includes(q) ||
        emp.role.toLowerCase().includes(q) ||
        emp.department.toLowerCase().includes(q)
      );
    }

    // Department filter
    if (selectedDepartment !== 'all') {
      result = result.filter(emp => emp.department.toLowerCase() === selectedDepartment.toLowerCase());
    }

    // Status filter
    if (selectedStatus !== 'all') {
      result = result.filter(emp => emp.status === selectedStatus);
    }

    // Work Mode filter
    if (selectedWorkMode !== 'all') {
      result = result.filter(emp => emp.workMode === selectedWorkMode);
    }

    // Sorting
    result.sort((a, b) => {
      let valA = a[sortField];
      let valB = b[sortField];

      if (typeof valA === 'string' && typeof valB === 'string') {
        const cmp = valA.localeCompare(valB);
        return sortDirection === 'asc' ? cmp : -cmp;
      }
      if (typeof valA === 'number' && typeof valB === 'number') {
        return sortDirection === 'asc' ? valA - valB : valB - valA;
      }
      return 0;
    });

    return result;
  }, [employees, searchQuery, selectedDepartment, selectedStatus, selectedWorkMode, sortField, sortDirection]);

  // Keep viewingEmployee updated if employee state changes in context
  const currentViewingEmployee = viewingEmployee 
    ? employees.find(e => e.id === viewingEmployee.id) || null 
    : null;

  return (
    <div className="flex h-dvh w-full overflow-hidden bg-neutral-50 dark:bg-neutral-950 font-sans text-neutral-900 dark:text-neutral-100 antialiased">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isDark={isDark}
        toggleTheme={toggleTheme}
        isMobileOpen={isMobileNavOpen}
        onCloseMobile={() => setIsMobileNavOpen(false)}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden bg-white dark:bg-neutral-900">
        {/* Top Header */}
        <Header
          activeTab={activeTab}
          onOpenAddModal={() => {
            setEditingEmployee(null);
            setIsAddModalOpen(true);
          }}
          onOpenMobileMenu={() => setIsMobileNavOpen(true)}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
        />

        {/* Tab Content Viewport */}
        {activeTab === 'directory' && (
          <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
            {/* Filter Bar */}
            <EmployeeFilterBar
              departments={departments}
              selectedDepartment={selectedDepartment}
              setSelectedDepartment={setSelectedDepartment}
              selectedStatus={selectedStatus}
              setSelectedStatus={setSelectedStatus}
              selectedWorkMode={selectedWorkMode}
              setSelectedWorkMode={setSelectedWorkMode}
              viewMode={viewMode}
              setViewMode={setViewMode}
              filteredCount={filteredEmployees.length}
              totalCount={employees.length}
            />

            {/* List or Grid View */}
            <div className="flex-1 overflow-y-auto">
              {viewMode === 'table' ? (
                <EmployeeTable
                  employees={filteredEmployees}
                  onSelectEmployee={emp => setViewingEmployee(emp)}
                  onEditEmployee={emp => setEditingEmployee(emp)}
                  onDeleteEmployee={emp => setDeletingEmployee(emp)}
                  sortField={sortField}
                  sortDirection={sortDirection}
                  onToggleSort={handleToggleSort}
                />
              ) : (
                <EmployeeCardGrid
                  employees={filteredEmployees}
                  onSelectEmployee={emp => setViewingEmployee(emp)}
                  onEditEmployee={emp => setEditingEmployee(emp)}
                  onDeleteEmployee={emp => setDeletingEmployee(emp)}
                />
              )}
            </div>
          </div>
        )}

        {activeTab === 'attendance' && <AttendanceView />}

        {activeTab === 'departments' && (
          <DepartmentsView
            onSelectEmployee={emp => setViewingEmployee(emp)}
          />
        )}

        {activeTab === 'payroll' && <PayrollView />}

        {activeTab === 'analytics' && <AnalyticsView />}
      </div>

      {/* Profile Detail Drawer/Modal */}
      <EmployeeDetailModal
        employee={currentViewingEmployee}
        onClose={() => setViewingEmployee(null)}
        onEdit={emp => {
          setViewingEmployee(null);
          setEditingEmployee(emp);
        }}
        onDelete={emp => {
          setViewingEmployee(null);
          setDeletingEmployee(emp);
        }}
      />

      {/* Add / Edit Form Modal */}
      <EmployeeFormModal
        employee={editingEmployee}
        isOpen={isAddModalOpen || editingEmployee !== null}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingEmployee(null);
        }}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        employee={deletingEmployee}
        isOpen={deletingEmployee !== null}
        onClose={() => setDeletingEmployee(null)}
        onConfirm={() => {
          if (deletingEmployee) {
            deleteEmployee(deletingEmployee.id);
            setDeletingEmployee(null);
          }
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <EmployeeProvider>
      <MainApp />
    </EmployeeProvider>
  );
}

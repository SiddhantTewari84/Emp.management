import React, { useState } from 'react';
import { 
  Banknote, 
  FileText, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Download, 
  X, 
  Printer, 
  Play
} from 'lucide-react';
import { useEmployees } from '../../context/EmployeeContext';
import { PayrollRecord } from '../../types/employee';

export const PayrollView: React.FC = () => {
  const { 
    payroll, 
    employees, 
    formatMoney, 
    updatePayrollStatus, 
    runBatchPayroll 
  } = useEmployees();

  const [selectedMonth, setSelectedMonth] = useState('October 2026');
  const [selectedSlip, setSelectedSlip] = useState<PayrollRecord | null>(null);

  // Filter records by selected month
  const currentMonthRecords = payroll.filter(p => p.month === selectedMonth);

  const totalMonthlyPayroll = currentMonthRecords.reduce((sum, p) => sum + p.netPay, 0);
  const totalGrossPayroll = currentMonthRecords.reduce((sum, p) => sum + p.baseSalary + p.hra + p.allowances, 0);
  const totalTaxDeductions = currentMonthRecords.reduce((sum, p) => sum + p.deductions + p.tax, 0);
  const paidCount = currentMonthRecords.filter(p => p.status === 'Paid').length;
  const pendingCount = currentMonthRecords.filter(p => p.status !== 'Paid').length;

  const handlePrintSlip = () => {
    window.print();
  };

  const handleRunBatch = () => {
    if (window.confirm(`Run and compute payroll for ${selectedMonth} for all active employees?`)) {
      runBatchPayroll(selectedMonth);
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto">
      {/* Top Overview Bar */}
      <div className="p-4 sm:p-6 border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4 mb-4">
          <div>
            <h2 className="text-base font-semibold text-neutral-900 dark:text-neutral-100">
              Compensation & Payroll Ledger
            </h2>
            <p className="text-xs text-neutral-500 dark:text-neutral-400">
              Salary disbursal logs, statutory PF/tax deductions, and generated pay slips.
            </p>
          </div>

          <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row sm:items-center">
            <select
              value={selectedMonth}
              onChange={e => setSelectedMonth(e.target.value)}
              aria-label="Payroll month"
              className="w-full px-2.5 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs font-medium text-neutral-900 dark:text-neutral-100 focus:outline-none sm:w-auto"
            >
              <option value="October 2026">October 2026 (Current)</option>
              <option value="September 2026">September 2026</option>
              <option value="August 2026">August 2026</option>
            </select>

            <button
              onClick={handleRunBatch}
              className="inline-flex w-full items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 rounded-md transition-colors sm:w-auto"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Process Month Payroll</span>
            </button>
          </div>
        </div>

        {/* 4 Payroll Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
          <div className="p-3 border border-neutral-200 dark:border-neutral-800 rounded bg-neutral-50/50 dark:bg-neutral-800/40">
            <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">Net Disbursed Take-Home</span>
            <span className="text-lg font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {formatMoney(totalMonthlyPayroll)}
            </span>
          </div>

          <div className="p-3 border border-neutral-200 dark:border-neutral-800 rounded bg-neutral-50/50 dark:bg-neutral-800/40">
            <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">Total Gross Wages</span>
            <span className="text-lg font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {formatMoney(totalGrossPayroll)}
            </span>
          </div>

          <div className="p-3 border border-neutral-200 dark:border-neutral-800 rounded bg-neutral-50/50 dark:bg-neutral-800/40">
            <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">Statutory Deductions & TDS</span>
            <span className="text-lg font-bold font-mono tabular-nums text-red-600 dark:text-red-400">
              {formatMoney(totalTaxDeductions)}
            </span>
          </div>

          <div className="p-3 border border-neutral-200 dark:border-neutral-800 rounded bg-neutral-50/50 dark:bg-neutral-800/40">
            <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">Disbursal Completion</span>
            <span className="text-lg font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
              {paidCount} / {currentMonthRecords.length} Paid
            </span>
          </div>
        </div>
      </div>

      {/* Table of Payroll Records */}
      <div className="p-4 sm:p-6">
        <div className="border border-neutral-200 dark:border-neutral-800 rounded-lg overflow-x-auto bg-white dark:bg-neutral-900">
          <table className="w-full min-w-[860px] text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50/75 dark:bg-neutral-800/40 text-neutral-500 dark:text-neutral-400 font-medium">
                <th className="py-2.5 px-4">Employee</th>
                <th className="py-2.5 px-4">Department</th>
                <th className="py-2.5 px-4 font-mono tabular-nums text-right">Basic Pay</th>
                <th className="py-2.5 px-4 font-mono tabular-nums text-right">Allowances</th>
                <th className="py-2.5 px-4 font-mono tabular-nums text-right">Deductions</th>
                <th className="py-2.5 px-4 font-mono tabular-nums text-right">Net Take-Home</th>
                <th className="py-2.5 px-4 text-center">Status</th>
                <th className="py-2.5 px-4 text-right">Pay Slip</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200/70 dark:divide-neutral-800/70">
              {currentMonthRecords.map(rec => (
                <tr key={rec.id} className="hover:bg-neutral-50/80 dark:hover:bg-neutral-800/40 transition-colors">
                  <td className="py-3 px-4">
                    <div className="flex flex-col">
                      <span className="font-medium text-neutral-900 dark:text-neutral-100">
                        {rec.employeeName}
                      </span>
                      <span className="text-[11px] font-mono tabular-nums text-neutral-400">
                        {rec.employeeCode} · {rec.role}
                      </span>
                    </div>
                  </td>

                  <td className="py-3 px-4 text-neutral-700 dark:text-neutral-300">
                    {rec.department}
                  </td>

                  <td className="py-3 px-4 font-mono tabular-nums text-right text-neutral-700 dark:text-neutral-300">
                    {formatMoney(rec.baseSalary)}
                  </td>

                  <td className="py-3 px-4 font-mono tabular-nums text-right text-neutral-700 dark:text-neutral-300">
                    {formatMoney(rec.hra + rec.allowances)}
                  </td>

                  <td className="py-3 px-4 font-mono tabular-nums text-right text-red-600 dark:text-red-400">
                    -{formatMoney(rec.deductions + rec.tax)}
                  </td>

                  <td className="py-3 px-4 font-mono tabular-nums text-right font-semibold text-neutral-900 dark:text-neutral-100">
                    {formatMoney(rec.netPay)}
                  </td>

                  <td className="py-3 px-4 text-center">
                    <button
                      onClick={() => updatePayrollStatus(rec.id, rec.status === 'Paid' ? 'Pending' : 'Paid')}
                      className={`inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded cursor-pointer transition-colors ${
                        rec.status === 'Paid'
                          ? 'text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40'
                          : 'text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40'
                      }`}
                      title="Click to toggle Paid/Pending"
                    >
                      {rec.status === 'Paid' ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                      <span>{rec.status}</span>
                    </button>
                  </td>

                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => setSelectedSlip(rec)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded transition-colors"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>Slip</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Salary Slip Modal */}
      {selectedSlip && (
        <div className="fixed inset-0 z-50 bg-neutral-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div 
            className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-lg w-full max-w-xl max-h-[92dvh] overflow-y-auto p-4 pt-12 sm:p-8 shadow-2xl relative"
            onClick={e => e.stopPropagation()}
          >
            {/* Modal Controls */}
            <div className="absolute top-3 right-3 sm:top-4 sm:right-4 flex items-center gap-2 print:hidden">
              <button
                onClick={handlePrintSlip}
                className="p-1.5 text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                title="Print slip"
              >
                <Printer className="w-4 h-4" />
              </button>
              <button
                onClick={() => setSelectedSlip(null)}
                className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                title="Close"
                aria-label="Close payslip"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Official Slip Content */}
            <div className="space-y-6">
              {/* Slip Header */}
              <div className="border-b border-neutral-200 dark:border-neutral-800 pb-4">
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h3 className="text-sm sm:text-base font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
                      Workbase Technologies Private Limited
                    </h3>
                    <p className="text-[11px] text-neutral-500">
                      Bengaluru Corporate Center, Karnataka, India
                    </p>
                  </div>
                  <div className="text-left sm:text-right">
                    <span className="text-[11px] text-neutral-400 block uppercase tracking-wider">
                      Payslip For
                    </span>
                    <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
                      {selectedSlip.month}
                    </span>
                  </div>
                </div>
              </div>

              {/* Employee Bio */}
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4 text-xs bg-neutral-50 dark:bg-neutral-800/40 p-3.5 rounded border border-neutral-200 dark:border-neutral-800">
                <div>
                  <span className="text-[11px] text-neutral-400 block">Employee Name</span>
                  <span className="font-semibold text-neutral-900 dark:text-neutral-100">
                    {selectedSlip.employeeName}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-neutral-400 block">Employee Code</span>
                  <span className="font-mono tabular-nums font-medium text-neutral-800 dark:text-neutral-200">
                    {selectedSlip.employeeCode}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-neutral-400 block">Designation</span>
                  <span className="text-neutral-800 dark:text-neutral-200">{selectedSlip.role}</span>
                </div>
                <div>
                  <span className="text-[11px] text-neutral-400 block">Department</span>
                  <span className="text-neutral-800 dark:text-neutral-200">{selectedSlip.department}</span>
                </div>
              </div>

              {/* Earnings vs Deductions Table */}
              <div className="border border-neutral-200 dark:border-neutral-800 rounded overflow-hidden text-xs">
                <div className="grid grid-cols-1 divide-y divide-neutral-200 dark:divide-neutral-800 sm:grid-cols-2 sm:divide-x sm:divide-y-0">
                  {/* Earnings Column */}
                  <div>
                    <div className="p-2.5 bg-neutral-100 dark:bg-neutral-800 font-semibold text-neutral-800 dark:text-neutral-200">
                      Gross Earnings
                    </div>
                    <div className="p-3 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-neutral-600 dark:text-neutral-400">Basic Pay</span>
                        <span className="font-mono tabular-nums">{formatMoney(selectedSlip.baseSalary)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-600 dark:text-neutral-400">House Rent Allowance</span>
                        <span className="font-mono tabular-nums">{formatMoney(selectedSlip.hra)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-600 dark:text-neutral-400">Special Allowances</span>
                        <span className="font-mono tabular-nums">{formatMoney(selectedSlip.allowances)}</span>
                      </div>
                      <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 flex justify-between font-medium">
                        <span>Total Gross</span>
                        <span className="font-mono tabular-nums">
                          {formatMoney(selectedSlip.baseSalary + selectedSlip.hra + selectedSlip.allowances)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Deductions Column */}
                  <div>
                    <div className="p-2.5 bg-neutral-100 dark:bg-neutral-800 font-semibold text-neutral-800 dark:text-neutral-200">
                      Deductions
                    </div>
                    <div className="p-3 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-neutral-600 dark:text-neutral-400">Provident Fund (PF)</span>
                        <span className="font-mono tabular-nums text-red-600 dark:text-red-400">
                          {formatMoney(selectedSlip.deductions)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-600 dark:text-neutral-400">Income Tax / TDS</span>
                        <span className="font-mono tabular-nums text-red-600 dark:text-red-400">
                          {formatMoney(selectedSlip.tax)}
                        </span>
                      </div>
                      <div className="flex justify-between text-neutral-400">
                        <span>Professional Tax</span>
                        <span className="font-mono tabular-nums">₹0</span>
                      </div>
                      <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 flex justify-between font-medium">
                        <span>Total Deductions</span>
                        <span className="font-mono tabular-nums text-red-600 dark:text-red-400">
                          {formatMoney(selectedSlip.deductions + selectedSlip.tax)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Net Pay Highlight */}
                <div className="p-3.5 bg-neutral-50 dark:bg-neutral-800/80 border-t border-neutral-200 dark:border-neutral-800 flex flex-col gap-1 font-bold text-sm sm:flex-row sm:items-center sm:justify-between">
                  <span className="text-neutral-900 dark:text-neutral-100">Net Take-Home Pay Disbursed</span>
                  <span className="font-mono tabular-nums text-neutral-900 dark:text-neutral-100 text-base">
                    {formatMoney(selectedSlip.netPay)}
                  </span>
                </div>
              </div>

              {/* Note / Disclaimer */}
              <p className="text-[10px] text-neutral-400 text-center">
                This is a computer-generated salary advice and does not require an ink signature.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

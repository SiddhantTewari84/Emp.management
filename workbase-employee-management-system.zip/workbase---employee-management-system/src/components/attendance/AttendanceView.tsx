import React, { useState } from 'react';
import { 
  CalendarCheck, 
  Check, 
  X, 
  Clock, 
  Plus, 
  Search, 
  User, 
  CheckCircle2, 
  XCircle,
  AlertCircle
} from 'lucide-react';
import { useEmployees } from '../../context/EmployeeContext';
import { AttendanceStatus, LeaveType } from '../../types/employee';

export const AttendanceView: React.FC = () => {
  const { 
    employees, 
    attendance, 
    leaveRequests, 
    markAttendance, 
    updateLeaveStatus, 
    applyLeave 
  } = useEmployees();

  const [activeSubTab, setActiveSubTab] = useState<'attendance' | 'leaves'>('attendance');
  const [searchTerm, setSearchTerm] = useState('');
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);

  // Form state for applying leave
  const [leaveForm, setLeaveForm] = useState({
    employeeId: employees[0]?.id || '',
    type: 'Paid Annual' as LeaveType,
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
    days: 1,
    reason: ''
  });

  // Calculate metrics for today
  const todayStr = '2026-10-18'; // current date from environment context
  const presentCount = attendance.filter(a => a.status === 'Present').length;
  const remoteCount = attendance.filter(a => a.status === 'Remote').length;
  const onLeaveCount = attendance.filter(a => a.status === 'On Leave').length;
  const halfDayCount = attendance.filter(a => a.status === 'Half Day').length;
  const totalEmployees = employees.length;
  const attendanceRate = totalEmployees > 0 
    ? Math.round(((presentCount + remoteCount + (halfDayCount * 0.5)) / totalEmployees) * 100) 
    : 0;

  const pendingLeaves = leaveRequests.filter(l => l.status === 'Pending');
  const pastLeaves = leaveRequests.filter(l => l.status !== 'Pending');

  // Filtered employees for attendance list
  const filteredEmployees = employees.filter(emp => {
    const term = searchTerm.toLowerCase();
    return (
      emp.firstName.toLowerCase().includes(term) ||
      emp.lastName.toLowerCase().includes(term) ||
      emp.employeeCode.toLowerCase().includes(term) ||
      emp.department.toLowerCase().includes(term)
    );
  });

  const handleApplyLeaveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = employees.find(e => e.id === leaveForm.employeeId);
    if (!emp || !leaveForm.reason.trim()) return;

    applyLeave({
      employeeId: emp.id,
      employeeName: `${emp.firstName} ${emp.lastName}`,
      employeeRole: emp.role,
      department: emp.department,
      type: leaveForm.type,
      startDate: leaveForm.startDate,
      endDate: leaveForm.endDate,
      days: Number(leaveForm.days) || 1,
      reason: leaveForm.reason.trim()
    });

    setIsApplyModalOpen(false);
    setLeaveForm({
      employeeId: employees[0]?.id || '',
      type: 'Paid Annual',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0],
      days: 1,
      reason: ''
    });
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto">
      {/* Top metrics strip */}
      <div className="p-4 sm:p-6 border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
        <div className="flex flex-col gap-3 mb-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-base font-semibold text-neutral-900 dark:text-neutral-100">
              Workforce Presence & Time Tracking
            </h2>
            <p className="text-xs text-neutral-500 dark:text-neutral-400">
              Real-time daily roster status for Sunday, October 18, 2026.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsApplyModalOpen(true)}
              className="inline-flex w-full items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 rounded-md transition-colors sm:w-auto"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Apply Leave Request</span>
            </button>
          </div>
        </div>

        {/* 5 KPI Metric blocks */}
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-5 sm:gap-3">
          <div className="p-3 border border-neutral-200 dark:border-neutral-800 rounded bg-neutral-50/50 dark:bg-neutral-800/40">
            <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">Present On-site</span>
            <span className="text-lg font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {presentCount}
            </span>
          </div>

          <div className="p-3 border border-neutral-200 dark:border-neutral-800 rounded bg-neutral-50/50 dark:bg-neutral-800/40">
            <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">Working Remote</span>
            <span className="text-lg font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {remoteCount}
            </span>
          </div>

          <div className="p-3 border border-neutral-200 dark:border-neutral-800 rounded bg-neutral-50/50 dark:bg-neutral-800/40">
            <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">On Approved Leave</span>
            <span className="text-lg font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {onLeaveCount}
            </span>
          </div>

          <div className="p-3 border border-neutral-200 dark:border-neutral-800 rounded bg-neutral-50/50 dark:bg-neutral-800/40">
            <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">Half Day Shift</span>
            <span className="text-lg font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {halfDayCount}
            </span>
          </div>

          <div className="col-span-2 p-3 border border-neutral-200 dark:border-neutral-800 rounded bg-neutral-50/50 dark:bg-neutral-800/40 sm:col-span-1">
            <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">Presence Ratio</span>
            <span className="text-lg font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
              {attendanceRate}%
            </span>
          </div>
        </div>
      </div>

      {/* Tabs bar */}
      <div className="px-4 sm:px-6 border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 flex flex-col gap-2 text-xs sm:flex-row sm:items-center sm:justify-between">
        <div className="flex gap-4 overflow-x-auto scrollbar-none w-full sm:w-auto">
          <button
            onClick={() => setActiveSubTab('attendance')}
            className={`shrink-0 whitespace-nowrap py-3 font-medium border-b-2 -mb-[1px] transition-colors ${
              activeSubTab === 'attendance'
                ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white'
                : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-300'
            }`}
          >
            <span className="sm:hidden">Attendance ({totalEmployees})</span>
            <span className="hidden sm:inline">Today&apos;s Attendance Roster ({totalEmployees})</span>
          </button>
          <button
            onClick={() => setActiveSubTab('leaves')}
            className={`shrink-0 whitespace-nowrap py-3 font-medium border-b-2 -mb-[1px] transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'leaves'
                ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white'
                : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-300'
            }`}
          >
            <span className="sm:hidden">Leaves</span>
            <span className="hidden sm:inline">Leave Requests Queue</span>
            {pendingLeaves.length > 0 && (
              <span className="px-1.5 py-0.2 text-[10px] font-mono tabular-nums font-semibold rounded bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900">
                {pendingLeaves.length}
              </span>
            )}
          </button>
        </div>

        {activeSubTab === 'attendance' && (
          <div className="relative w-full mb-2 sm:my-2 sm:w-56">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-neutral-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Filter employee..."
              className="w-full pl-8 pr-2.5 py-1 text-xs bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-neutral-900 dark:text-neutral-100 focus:outline-none"
            />
          </div>
        )}
      </div>

      {/* Content Area */}
      <div className="p-4 sm:p-6">
        {activeSubTab === 'attendance' && (
          <div className="border border-neutral-200 dark:border-neutral-800 rounded-lg overflow-x-auto bg-white dark:bg-neutral-900">
            <table className="w-full min-w-[900px] text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50/75 dark:bg-neutral-800/40 text-neutral-500 dark:text-neutral-400 font-medium">
                  <th className="py-2.5 px-4">Employee</th>
                  <th className="py-2.5 px-4">Department & Mode</th>
                  <th className="py-2.5 px-4">Current Status Today</th>
                  <th className="py-2.5 px-4 font-mono tabular-nums">Check-in Time</th>
                  <th className="py-2.5 px-4 font-mono tabular-nums">Logged Hours</th>
                  <th className="py-2.5 px-4 text-right">Quick Mark Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200/70 dark:divide-neutral-800/70">
                {filteredEmployees.map(emp => {
                  const record = attendance.find(a => a.employeeId === emp.id);
                  const currentStatus = record?.status || (emp.status === 'On Leave' ? 'On Leave' : 'Present');

                  return (
                    <tr key={emp.id} className="hover:bg-neutral-50/80 dark:hover:bg-neutral-800/40 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex flex-col">
                          <span className="font-medium text-neutral-900 dark:text-neutral-100">
                            {emp.firstName} {emp.lastName}
                          </span>
                          <span className="text-[11px] font-mono tabular-nums text-neutral-400">
                            {emp.employeeCode} · {emp.role}
                          </span>
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="text-neutral-700 dark:text-neutral-300 font-medium">{emp.department}</span>
                        <span className="text-[11px] text-neutral-400 block">{emp.workMode}</span>
                      </td>

                      <td className="py-3 px-4">
                        <span className="inline-flex items-center gap-1.5 font-medium text-neutral-800 dark:text-neutral-200">
                          <span className={`w-1.5 h-1.5 rounded-full ${
                            currentStatus === 'Present' ? 'bg-emerald-500' :
                            currentStatus === 'Remote' ? 'bg-sky-500' :
                            currentStatus === 'On Leave' ? 'bg-amber-500' :
                            currentStatus === 'Half Day' ? 'bg-orange-500' : 'bg-red-500'
                          }`} />
                          {currentStatus}
                        </span>
                      </td>

                      <td className="py-3 px-4 font-mono tabular-nums text-neutral-600 dark:text-neutral-400">
                        {record?.checkIn || '—'}
                      </td>

                      <td className="py-3 px-4 font-mono tabular-nums text-neutral-600 dark:text-neutral-400">
                        {record?.workHours ? `${record.workHours} hrs` : '—'}
                      </td>

                      {/* Quick mark buttons */}
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-1 p-0.5 bg-neutral-100 dark:bg-neutral-800 rounded">
                          {(['Present', 'Remote', 'Half Day', 'On Leave'] as AttendanceStatus[]).map(st => (
                            <button
                              key={st}
                              onClick={() => markAttendance(emp.id, st)}
                              className={`px-2 py-0.5 text-[10px] font-medium rounded transition-colors ${
                                currentStatus === st
                                  ? 'bg-white text-neutral-900 dark:bg-neutral-700 dark:text-white shadow-xs font-semibold'
                                  : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
                              }`}
                            >
                              {st}
                            </button>
                          ))}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {activeSubTab === 'leaves' && (
          <div className="space-y-6">
            {/* Pending Approvals */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider">
                  Pending Approvals Required ({pendingLeaves.length})
                </h3>
              </div>

              {pendingLeaves.length === 0 ? (
                <div className="p-8 border border-neutral-200 dark:border-neutral-800 rounded-lg text-center text-xs text-neutral-400">
                  All employee leave requests have been reviewed. No pending approvals.
                </div>
              ) : (
                <div className="border border-neutral-200 dark:border-neutral-800 rounded-lg divide-y divide-neutral-200 dark:divide-neutral-800 bg-white dark:bg-neutral-900">
                  {pendingLeaves.map(leave => (
                    <div key={leave.id} className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                          <span className="font-semibold text-xs text-neutral-900 dark:text-neutral-100">
                            {leave.employeeName}
                          </span>
                          <span className="text-[11px] text-neutral-400">· {leave.employeeRole} ({leave.department})</span>
                          <span className="text-[11px] font-medium text-neutral-700 dark:text-neutral-300">
                            [{leave.type} Leave]
                          </span>
                        </div>
                        <p className="text-xs text-neutral-600 dark:text-neutral-300 mt-1">
                          &quot;{leave.reason}&quot;
                        </p>
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-neutral-400 font-mono tabular-nums mt-1">
                          <span>Dates: {leave.startDate} to {leave.endDate}</span>
                          <span>Total: {leave.days} {leave.days === 1 ? 'day' : 'days'}</span>
                          <span>Applied on: {leave.appliedDate}</span>
                        </div>
                      </div>

                      <div className="flex w-full items-center gap-2 shrink-0 sm:w-auto">
                        <button
                          onClick={() => updateLeaveStatus(leave.id, 'Approved')}
                          className="inline-flex flex-1 items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-md transition-colors sm:flex-none"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Approve</span>
                        </button>
                        <button
                          onClick={() => updateLeaveStatus(leave.id, 'Rejected')}
                          className="inline-flex flex-1 items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-700 dark:text-neutral-300 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-md transition-colors sm:flex-none"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Past Decisions History */}
            <div>
              <h3 className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider mb-3">
                Processed Requests History ({pastLeaves.length})
              </h3>

              <div className="border border-neutral-200 dark:border-neutral-800 rounded-lg overflow-x-auto bg-white dark:bg-neutral-900">
                <table className="w-full min-w-[760px] text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50/75 dark:bg-neutral-800/40 text-neutral-500 font-medium">
                      <th className="py-2.5 px-4">Employee</th>
                      <th className="py-2.5 px-4">Type</th>
                      <th className="py-2.5 px-4 font-mono tabular-nums">Duration</th>
                      <th className="py-2.5 px-4">Reason</th>
                      <th className="py-2.5 px-4">Outcome</th>
                      <th className="py-2.5 px-4">Reviewed By</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-200/70 dark:divide-neutral-800/70">
                    {pastLeaves.map(lv => (
                      <tr key={lv.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30">
                        <td className="py-2.5 px-4 font-medium text-neutral-900 dark:text-neutral-100">
                          {lv.employeeName}
                        </td>
                        <td className="py-2.5 px-4 text-neutral-600 dark:text-neutral-400">
                          {lv.type}
                        </td>
                        <td className="py-2.5 px-4 font-mono tabular-nums text-neutral-600 dark:text-neutral-400">
                          {lv.startDate} to {lv.endDate} ({lv.days}d)
                        </td>
                        <td className="py-2.5 px-4 text-neutral-600 dark:text-neutral-400 max-w-xs truncate">
                          {lv.reason}
                        </td>
                        <td className="py-2.5 px-4">
                          <span className={`inline-flex items-center gap-1 font-medium ${
                            lv.status === 'Approved' ? 'text-emerald-600 dark:text-emerald-400' : 'text-neutral-500'
                          }`}>
                            {lv.status === 'Approved' ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                            {lv.status}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 text-neutral-500">
                          {lv.reviewedBy || 'HR Admin'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Apply Leave Modal */}
      {isApplyModalOpen && (
        <div className="fixed inset-0 z-50 bg-neutral-900/40 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div 
            className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-lg w-full max-w-md max-h-[92dvh] overflow-y-auto p-4 sm:p-6 shadow-xl"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
                Submit Leave Application
              </h3>
              <button
                onClick={() => setIsApplyModalOpen(false)}
                className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
                aria-label="Close form"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleApplyLeaveSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Employee
                </label>
                <select
                  value={leaveForm.employeeId}
                  onChange={e => setLeaveForm({ ...leaveForm, employeeId: e.target.value })}
                  className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
                >
                  {employees.map(e => (
                    <option key={e.id} value={e.id}>
                      {e.firstName} {e.lastName} ({e.employeeCode})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Leave Category
                </label>
                <select
                  value={leaveForm.type}
                  onChange={e => setLeaveForm({ ...leaveForm, type: e.target.value as LeaveType })}
                  className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
                >
                  <option value="Paid Annual">Paid Annual Leave</option>
                  <option value="Casual">Casual Leave</option>
                  <option value="Sick">Sick / Medical Leave</option>
                  <option value="Parental">Parental Leave</option>
                  <option value="Unpaid">Unpaid Leave</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2 sm:gap-3">
                <div>
                  <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={leaveForm.startDate}
                    onChange={e => setLeaveForm({ ...leaveForm, startDate: e.target.value })}
                    className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs font-mono tabular-nums text-neutral-900 dark:text-neutral-100 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                    End Date
                  </label>
                  <input
                    type="date"
                    value={leaveForm.endDate}
                    onChange={e => setLeaveForm({ ...leaveForm, endDate: e.target.value })}
                    className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs font-mono tabular-nums text-neutral-900 dark:text-neutral-100 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Total Working Days
                </label>
                <input
                  type="number"
                  min="0.5"
                  step="0.5"
                  value={leaveForm.days}
                  onChange={e => setLeaveForm({ ...leaveForm, days: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs font-mono tabular-nums text-neutral-900 dark:text-neutral-100 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Reason / Handover Note *
                </label>
                <textarea
                  required
                  rows={2}
                  value={leaveForm.reason}
                  onChange={e => setLeaveForm({ ...leaveForm, reason: e.target.value })}
                  placeholder="State reason and person handling immediate escalations..."
                  className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
                />
              </div>

              <div className="pt-3 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsApplyModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 rounded transition-colors"
                >
                  Submit Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

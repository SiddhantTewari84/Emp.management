import React, { useState } from 'react';
import { Building2, Plus, Users, UserCheck, X } from 'lucide-react';
import { useEmployees } from '../../context/EmployeeContext';
import { Department, Employee } from '../../types/employee';

interface DepartmentsViewProps {
  onSelectEmployee: (emp: Employee) => void;
}

export const DepartmentsView: React.FC<DepartmentsViewProps> = ({ onSelectEmployee }) => {
  const { departments, employees, formatMoney, addDepartment } = useEmployees();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedDeptId, setSelectedDeptId] = useState<string | null>(null);

  const [newDept, setNewDept] = useState({
    name: '',
    code: '',
    lead: '',
    budgetAnnual: 5000000,
    description: ''
  });

  const handleAddDeptSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDept.name.trim() || !newDept.code.trim()) return;

    addDepartment({
      name: newDept.name.trim(),
      code: newDept.code.trim().toUpperCase(),
      lead: newDept.lead.trim() || 'To be appointed',
      budgetAnnual: Number(newDept.budgetAnnual) || 1000000,
      description: newDept.description.trim() || 'Department operations and team deliverables.'
    });

    setIsAddModalOpen(false);
    setNewDept({
      name: '',
      code: '',
      lead: '',
      budgetAnnual: 5000000,
      description: ''
    });
  };

  const getDeptEmployees = (deptName: string) => {
    return employees.filter(e => e.department.toLowerCase() === deptName.toLowerCase());
  };

  const totalCompanyBudget = departments.reduce((acc, d) => acc + d.budgetAnnual, 0);

  return (
    <div className="flex-1 flex flex-col overflow-y-auto p-4 sm:p-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4 mb-5 sm:mb-6">
        <div>
          <h2 className="text-base font-semibold text-neutral-900 dark:text-neutral-100">
            Departments & Organizational Units
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            Headcount allocation, departmental leads, and annual operating budgets.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex w-full items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 rounded-md transition-colors sm:w-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Department</span>
        </button>
      </div>

      {/* Grid of Department Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 mb-8">
        {departments.map(dept => {
          const members = getDeptEmployees(dept.name);
          const totalSpend = members.reduce((sum, m) => sum + m.salaryAnnual, 0);

          return (
            <div
              key={dept.id}
              className="border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 rounded-lg p-5 flex flex-col justify-between hover:border-neutral-300 dark:hover:border-neutral-700 transition-colors"
            >
              <div>
                {/* Title & Code */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-neutral-400" />
                    <h3 className="font-semibold text-xs text-neutral-900 dark:text-neutral-100">
                      {dept.name}
                    </h3>
                  </div>
                  <span className="font-mono text-[11px] font-semibold text-neutral-500 bg-neutral-100 dark:bg-neutral-800 px-1.5 py-0.5 rounded">
                    {dept.code}
                  </span>
                </div>

                <p className="text-[11px] text-neutral-500 dark:text-neutral-400 line-clamp-2 mb-4">
                  {dept.description}
                </p>

                {/* Lead and headcount */}
                <div className="space-y-2 border-t border-neutral-100 dark:border-neutral-800/80 pt-3 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-500 text-[11px]">Department Lead</span>
                    <span className="font-medium text-neutral-800 dark:text-neutral-200">{dept.lead}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-neutral-500 text-[11px]">Staff Count</span>
                    <span className="font-mono tabular-nums font-semibold text-neutral-900 dark:text-neutral-100">
                      {members.length} {members.length === 1 ? 'member' : 'members'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-neutral-500 text-[11px]">Payroll Spend</span>
                    <span className="font-mono tabular-nums font-medium text-neutral-800 dark:text-neutral-200">
                      {formatMoney(totalSpend)} / yr
                    </span>
                  </div>
                </div>
              </div>

              {/* Members Preview */}
              <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800">
                <span className="text-[10px] text-neutral-400 uppercase tracking-wider block mb-2">
                  Assigned Team Members
                </span>
                {members.length === 0 ? (
                  <span className="text-[11px] text-neutral-400 italic">No staff assigned yet</span>
                ) : (
                  <div className="space-y-1.5 max-h-36 overflow-y-auto">
                    {members.map(m => (
                      <div
                        key={m.id}
                        onClick={() => onSelectEmployee(m)}
                        className="flex items-center justify-between p-1.5 rounded hover:bg-neutral-50 dark:hover:bg-neutral-800 cursor-pointer transition-colors text-xs"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <span className="w-5 h-5 rounded-full bg-neutral-200 dark:bg-neutral-700 flex items-center justify-center text-[10px] font-medium shrink-0">
                            {m.firstName.charAt(0)}{m.lastName.charAt(0)}
                          </span>
                          <span className="truncate text-neutral-800 dark:text-neutral-200 font-medium">
                            {m.firstName} {m.lastName}
                          </span>
                        </div>
                        <span className="max-w-[45%] truncate text-[11px] text-neutral-400 font-mono tabular-nums shrink-0">
                          {m.role}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Department Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-neutral-900/40 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div 
            className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-lg w-full max-w-md max-h-[92dvh] overflow-y-auto p-4 sm:p-6 shadow-xl"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
                Create Department
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
                aria-label="Close form"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddDeptSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Department Name *
                </label>
                <input
                  type="text"
                  required
                  value={newDept.name}
                  onChange={e => setNewDept({ ...newDept, name: e.target.value })}
                  placeholder="e.g. Information Security"
                  className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                    Department Code *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={4}
                    value={newDept.code}
                    onChange={e => setNewDept({ ...newDept, code: e.target.value.toUpperCase() })}
                    placeholder="SEC"
                    className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs font-mono uppercase text-neutral-900 dark:text-neutral-100 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                    Department Lead
                  </label>
                  <input
                    type="text"
                    value={newDept.lead}
                    onChange={e => setNewDept({ ...newDept, lead: e.target.value })}
                    placeholder="e.g. Anita Roy"
                    className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Annual Budget
                </label>
                <input
                  type="number"
                  value={newDept.budgetAnnual}
                  onChange={e => setNewDept({ ...newDept, budgetAnnual: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs font-mono tabular-nums text-neutral-900 dark:text-neutral-100 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Purpose / Mandate
                </label>
                <textarea
                  rows={2}
                  value={newDept.description}
                  onChange={e => setNewDept({ ...newDept, description: e.target.value })}
                  placeholder="Key functional scope, deliverables, and team charter..."
                  className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
                />
              </div>

              <div className="pt-3 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 rounded transition-colors"
                >
                  Create Department
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { Employee } from '../../types/employee';

interface DeleteConfirmModalProps {
  employee: Employee | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  employee,
  isOpen,
  onClose,
  onConfirm
}) => {
  if (!isOpen || !employee) return null;

  return (
    <div className="fixed inset-0 z-50 bg-neutral-900/40 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div 
        className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-lg w-full max-w-sm p-4 sm:p-5 shadow-xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-full bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
              Remove Employee Record?
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
              Are you sure you want to delete <span className="font-medium text-neutral-800 dark:text-neutral-200">{employee.firstName} {employee.lastName}</span> ({employee.employeeCode})? This will archive their attendance records and active pay slip assignments.
            </p>
          </div>
        </div>

        <div className="mt-5 flex items-center justify-end gap-2 text-xs">
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 rounded text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="px-3.5 py-1.5 rounded font-medium text-white bg-red-600 hover:bg-red-700 transition-colors"
          >
            Delete Record
          </button>
        </div>
      </div>
    </div>
  );
};

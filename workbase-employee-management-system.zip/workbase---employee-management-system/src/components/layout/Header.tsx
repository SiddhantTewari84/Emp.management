import React from 'react';
import { Plus, Search, Download, Menu } from 'lucide-react';
import { NavTab } from './Sidebar';
import { useEmployees } from '../../context/EmployeeContext';

interface HeaderProps {
  activeTab: NavTab;
  onOpenAddModal: () => void;
  onOpenMobileMenu: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

const TAB_TITLES: Record<NavTab, { section: string; title: string }> = {
  directory: { section: 'Organization', title: 'Employee Directory' },
  attendance: { section: 'Operations', title: 'Attendance & Leaves' },
  departments: { section: 'Structure', title: 'Departments & Teams' },
  payroll: { section: 'Compensation', title: 'Payroll Ledger' },
  analytics: { section: 'Intelligence', title: 'Workforce Analytics' }
};

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onOpenAddModal,
  onOpenMobileMenu,
  searchQuery,
  setSearchQuery
}) => {
  const { exportEmployeesCSV, employees } = useEmployees();
  const info = TAB_TITLES[activeTab];

  const renderSearchField = (placeholder: string) => (
    <div className="relative w-full">
      <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
      <input
        type="text"
        value={searchQuery}
        onChange={e => setSearchQuery(e.target.value)}
        placeholder={placeholder}
        enterKeyHint="search"
        className="w-full pl-9 pr-12 py-1.5 text-xs bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-md text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 focus:outline-none focus:border-neutral-400 dark:focus:border-neutral-500 transition-colors"
      />
      {searchQuery && (
        <button
          onClick={() => setSearchQuery('')}
          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
        >
          Clear
        </button>
      )}
    </div>
  );

  return (
    <header className="shrink-0 border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
      <div className="flex h-14 items-center gap-2 px-4 sm:h-16 sm:px-6">
        {/* Mobile menu trigger */}
        <button
          onClick={onOpenMobileMenu}
          className="-ml-1.5 p-1.5 text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors lg:hidden"
          aria-label="Open navigation"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Breadcrumb Area */}
        <div className="flex min-w-0 items-center gap-2 text-xs">
          <span className="hidden sm:inline text-neutral-400 dark:text-neutral-500">{info.section}</span>
          <span className="hidden sm:inline text-neutral-300 dark:text-neutral-600">/</span>
          <h1 className="truncate text-sm font-semibold text-neutral-900 dark:text-neutral-100 sm:whitespace-nowrap">
            {info.title}
          </h1>
          <span className="hidden md:inline text-neutral-400 dark:text-neutral-500 font-mono tabular-nums text-[11px] ml-1">
            ({employees.length} records)
          </span>
        </div>

        {/* Mobile add shortcut */}
        <button
          onClick={onOpenAddModal}
          className="ml-auto inline-flex shrink-0 items-center justify-center rounded-md bg-neutral-900 p-2 text-white hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 transition-colors sm:hidden"
          aria-label="Add employee"
        >
          <Plus className="w-4 h-4" />
        </button>

        {/* Desktop actions and search */}
        <div className="ml-auto hidden items-center gap-3 sm:flex">
          <div className="hidden w-56 md:block xl:w-80">
            {renderSearchField('Search by name, role, email, or EMP ID...')}
          </div>

          {/* Export CSV */}
          <button
            onClick={exportEmployeesCSV}
            className="hidden xl:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-700 dark:text-neutral-300 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-md transition-colors whitespace-nowrap shrink-0"
            title="Export CSV Roster"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          {/* Primary Add Employee */}
          <button
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 rounded-md transition-colors whitespace-nowrap shrink-0 shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Employee</span>
          </button>
        </div>
      </div>

      {/* Compact search row (mobile/tablet) */}
      <div className="px-4 pb-2.5 md:hidden">{renderSearchField('Search employees...')}</div>
    </header>
  );
};

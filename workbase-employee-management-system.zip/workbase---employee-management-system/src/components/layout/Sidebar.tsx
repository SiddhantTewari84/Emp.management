import React from 'react';
import { 
  Users, 
  CalendarCheck, 
  Building2, 
  Banknote, 
  BarChart3, 
  RotateCcw,
  Sun,
  Moon,
  Briefcase,
  X
} from 'lucide-react';
import { useEmployees } from '../../context/EmployeeContext';

export type NavTab = 'directory' | 'attendance' | 'departments' | 'payroll' | 'analytics';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  isDark: boolean;
  toggleTheme: () => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isDark,
  toggleTheme,
  isMobileOpen,
  onCloseMobile
}) => {
  const { employees, leaveRequests, currency, setCurrency, resetToDefaultData } = useEmployees();

  const pendingLeaves = leaveRequests.filter(l => l.status === 'Pending').length;

  const navItems: { id: NavTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    {
      id: 'directory',
      label: 'Employees',
      icon: <Users className="w-4 h-4" />
    },
    {
      id: 'attendance',
      label: 'Attendance & Leaves',
      icon: <CalendarCheck className="w-4 h-4" />,
      badge: pendingLeaves > 0 ? pendingLeaves : undefined
    },
    {
      id: 'departments',
      label: 'Departments',
      icon: <Building2 className="w-4 h-4" />
    },
    {
      id: 'payroll',
      label: 'Payroll & Salaries',
      icon: <Banknote className="w-4 h-4" />
    },
    {
      id: 'analytics',
      label: 'Organization Insights',
      icon: <BarChart3 className="w-4 h-4" />
    }
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-neutral-900/40 backdrop-blur-xs lg:hidden"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 w-72 max-w-[85vw] border-r border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 flex flex-col justify-between shrink-0 select-none transition-transform duration-200 ease-out lg:static lg:z-auto lg:w-64 lg:max-w-none lg:translate-x-0 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
      <div>
        {/* Brand header */}
        <div className="h-16 px-5 flex items-center gap-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="w-8 h-8 rounded-lg bg-neutral-900 dark:bg-white flex items-center justify-center text-white dark:text-neutral-900 font-bold text-sm">
            <Briefcase className="w-4 h-4" />
          </div>
          <div className="flex flex-col">
            <span className="font-semibold text-sm tracking-tight text-neutral-900 dark:text-neutral-100">
              Workbase
            </span>
            <span className="text-[11px] text-neutral-500 dark:text-neutral-400">
              Employee Management
            </span>
          </div>
          <button
            onClick={onCloseMobile}
            className="ml-auto p-1.5 -mr-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors lg:hidden"
            aria-label="Close navigation"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick summary stat */}
        <div className="px-5 py-3 border-b border-neutral-100 dark:border-neutral-800/60 bg-neutral-50/50 dark:bg-neutral-900/50 text-xs text-neutral-500 dark:text-neutral-400 flex items-center justify-between">
          <span>Active Staff</span>
          <span className="font-mono tabular-nums font-medium text-neutral-900 dark:text-neutral-200">
            {employees.filter(e => e.status === 'Active').length} / {employees.length}
          </span>
        </div>

        {/* Navigation list */}
        <nav className="p-3 space-y-1">
          {navItems.map(item => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-md transition-colors ${
                  isActive
                    ? 'bg-neutral-100 text-neutral-900 dark:bg-neutral-800 dark:text-white font-semibold'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className={isActive ? 'text-neutral-900 dark:text-white' : 'text-neutral-500 dark:text-neutral-400'}>
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span className="px-1.5 py-0.2 text-[10px] font-mono tabular-nums font-semibold rounded bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom controls */}
      <div className="p-3 border-t border-neutral-200 dark:border-neutral-800 space-y-2">
        {/* Currency Switcher */}
        <div className="flex items-center justify-between px-2 py-1 text-xs text-neutral-500 dark:text-neutral-400">
          <span>Currency</span>
          <div className="flex items-center gap-1 p-0.5 bg-neutral-100 dark:bg-neutral-800 rounded">
            <button
              onClick={() => setCurrency('INR')}
              className={`px-2 py-0.5 text-[11px] font-medium rounded ${
                currency === 'INR'
                  ? 'bg-white text-neutral-900 dark:bg-neutral-700 dark:text-white shadow-xs'
                  : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              ₹ INR
            </button>
            <button
              onClick={() => setCurrency('USD')}
              className={`px-2 py-0.5 text-[11px] font-medium rounded ${
                currency === 'USD'
                  ? 'bg-white text-neutral-900 dark:bg-neutral-700 dark:text-white shadow-xs'
                  : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              $ USD
            </button>
          </div>
        </div>

        {/* Theme and Reset actions */}
        <div className="flex items-center justify-between pt-1 gap-1">
          <button
            onClick={toggleTheme}
            className="flex-1 flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-md transition-colors"
            title="Toggle theme"
          >
            {isDark ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
            <span>{isDark ? 'Light' : 'Dark'}</span>
          </button>

          <button
            onClick={() => {
              if (window.confirm('Reset all employee and attendance data to default demo state?')) {
                resetToDefaultData();
              }
            }}
            className="flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-md transition-colors"
            title="Reset sample records"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>
      </aside>
    </>
  );
};

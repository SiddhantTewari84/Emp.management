import React from 'react';
import { LayoutGrid, Table, X } from 'lucide-react';
import { Department, EmployeeStatus, WorkMode } from '../../types/employee';

interface EmployeeFilterBarProps {
  departments: Department[];
  selectedDepartment: string;
  setSelectedDepartment: (dept: string) => void;
  selectedStatus: string;
  setSelectedStatus: (status: string) => void;
  selectedWorkMode: string;
  setSelectedWorkMode: (mode: string) => void;
  viewMode: 'table' | 'grid';
  setViewMode: (mode: 'table' | 'grid') => void;
  filteredCount: number;
  totalCount: number;
}

export const EmployeeFilterBar: React.FC<EmployeeFilterBarProps> = ({
  departments,
  selectedDepartment,
  setSelectedDepartment,
  selectedStatus,
  setSelectedStatus,
  selectedWorkMode,
  setSelectedWorkMode,
  viewMode,
  setViewMode,
  filteredCount,
  totalCount
}) => {
  const hasActiveFilters = 
    selectedDepartment !== 'all' || 
    selectedStatus !== 'all' || 
    selectedWorkMode !== 'all';

  const clearAllFilters = () => {
    setSelectedDepartment('all');
    setSelectedStatus('all');
    setSelectedWorkMode('all');
  };

  return (
    <div className="flex flex-col gap-2.5 px-4 py-2.5 border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900/60 sm:gap-3 sm:px-6 sm:py-2">
      {/* Top row: Department selector chips (functional segmented buttons) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        <span className="text-neutral-400 dark:text-neutral-500 mr-1 text-[11px] whitespace-nowrap">
          Department:
        </span>
        <button
          onClick={() => setSelectedDepartment('all')}
          className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
            selectedDepartment === 'all'
              ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
              : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800'
          }`}
        >
          All ({totalCount})
        </button>
        {departments.map(dept => (
          <button
            key={dept.id}
            onClick={() => setSelectedDepartment(dept.name)}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              selectedDepartment === dept.name
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800'
            }`}
          >
            {dept.name}
          </button>
        ))}
      </div>

      {/* Second row: Status & Work Mode select controls + View switch */}
      <div className="flex items-center gap-2 text-xs">
        <div className="flex min-w-0 flex-1 items-center gap-2">
          {/* Status select */}
          <select
            id="status-select"
            aria-label="Filter by status"
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="min-w-0 flex-1 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded px-2 py-1.5 text-xs text-neutral-800 dark:text-neutral-200 focus:outline-none sm:flex-none sm:py-1"
          >
            <option value="all">All Statuses</option>
            <option value="Active">Active</option>
            <option value="On Leave">On Leave</option>
            <option value="Probation">Probation</option>
            <option value="Inactive">Inactive</option>
          </select>

          {/* Work mode select */}
          <select
            id="mode-select"
            aria-label="Filter by work mode"
            value={selectedWorkMode}
            onChange={e => setSelectedWorkMode(e.target.value)}
            className="min-w-0 flex-1 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded px-2 py-1.5 text-xs text-neutral-800 dark:text-neutral-200 focus:outline-none sm:flex-none sm:py-1"
          >
            <option value="all">All Modes</option>
            <option value="On-site">On-site</option>
            <option value="Hybrid">Hybrid</option>
            <option value="Remote">Remote</option>
          </select>
        </div>

        {/* View mode switcher */}
        <div className="flex shrink-0 items-center p-0.5 bg-neutral-100 dark:bg-neutral-800 rounded border border-neutral-200 dark:border-neutral-700">
          <button
            onClick={() => setViewMode('table')}
            className={`p-1.5 sm:p-1 rounded transition-colors ${
              viewMode === 'table'
                ? 'bg-white text-neutral-900 dark:bg-neutral-700 dark:text-white shadow-xs'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200'
            }`}
            title="Table View"
            aria-label="Table view"
          >
            <Table className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setViewMode('grid')}
            className={`p-1.5 sm:p-1 rounded transition-colors ${
              viewMode === 'grid'
                ? 'bg-white text-neutral-900 dark:bg-neutral-700 dark:text-white shadow-xs'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200'
            }`}
            title="Card Grid View"
            aria-label="Card grid view"
          >
            <LayoutGrid className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Desktop count + reset */}
        <span className="ml-auto hidden shrink-0 text-[11px] font-mono tabular-nums text-neutral-400 dark:text-neutral-500 sm:inline">
          Showing {filteredCount} of {totalCount} employees
        </span>
        {hasActiveFilters && (
          <button
            onClick={clearAllFilters}
            className="hidden shrink-0 items-center gap-1 text-[11px] text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200 sm:inline-flex"
          >
            <X className="w-3 h-3" />
            <span>Reset filters</span>
          </button>
        )}
      </div>

      {/* Mobile count + reset filters */}
      <div className="flex items-center justify-between gap-3 text-[11px] sm:hidden">
        <span className="text-neutral-400 dark:text-neutral-500 font-mono tabular-nums">
          Showing {filteredCount} of {totalCount} employees
        </span>
        {hasActiveFilters && (
          <button
            onClick={clearAllFilters}
            className="inline-flex shrink-0 items-center gap-1 text-[11px] text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200"
          >
            <X className="w-3 h-3" />
            <span>Reset filters</span>
          </button>
        )}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { 
  X, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Briefcase, 
  Building, 
  UserCheck, 
  CreditCard, 
  AlertCircle,
  FileText,
  Clock,
  Edit3,
  Trash2
} from 'lucide-react';
import { Employee, EmployeeStatus } from '../../types/employee';
import { useEmployees } from '../../context/EmployeeContext';

interface EmployeeDetailModalProps {
  employee: Employee | null;
  onClose: () => void;
  onEdit: (emp: Employee) => void;
  onDelete: (emp: Employee) => void;
}

export const EmployeeDetailModal: React.FC<EmployeeDetailModalProps> = ({
  employee,
  onClose,
  onEdit,
  onDelete
}) => {
  const { formatMoney, updateEmployee, attendance, leaveRequests } = useEmployees();
  const [activeTab, setActiveTab] = useState<'overview' | 'compensation' | 'leave' | 'emergency'>('overview');

  if (!employee) return null;

  const empAttendance = attendance.filter(a => a.employeeId === employee.id);
  const empLeaves = leaveRequests.filter(l => l.employeeId === employee.id);

  const getStatusColor = (status: EmployeeStatus) => {
    switch (status) {
      case 'Active': return 'bg-emerald-500';
      case 'On Leave': return 'bg-amber-500';
      case 'Probation': return 'bg-sky-500';
      default: return 'bg-neutral-400';
    }
  };

  const getInitials = (first: string, last: string) => {
    return `${first.charAt(0)}${last.charAt(0)}`.toUpperCase();
  };

  const monthlyGross = Math.round(employee.salaryAnnual / 12);
  const monthlyBase = Math.round(monthlyGross * 0.50);
  const monthlyHra = Math.round(monthlyGross * 0.30);
  const monthlyAllowances = Math.round(monthlyGross * 0.20);
  const monthlyPf = Math.round(monthlyBase * 0.12);
  const monthlyTax = Math.round(monthlyGross * 0.10);
  const monthlyNet = monthlyGross - monthlyPf - monthlyTax;

  return (
    <div className="fixed inset-0 z-50 bg-neutral-900/40 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div 
        className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-lg w-full max-w-2xl max-h-[92dvh] flex flex-col shadow-xl overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-neutral-200 dark:border-neutral-800 flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-center gap-3 sm:gap-4">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-100 flex items-center justify-center font-semibold text-sm sm:text-base shrink-0">
              {getInitials(employee.firstName, employee.lastName)}
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                <h2 className="text-sm sm:text-base font-semibold text-neutral-900 dark:text-neutral-100">
                  {employee.firstName} {employee.lastName}
                </h2>
                <span className="font-mono tabular-nums text-[11px] sm:text-xs text-neutral-400 dark:text-neutral-500">
                  {employee.employeeCode}
                </span>
                <span className="inline-flex items-center gap-1.5 text-[11px] sm:text-xs text-neutral-600 dark:text-neutral-400 sm:ml-2">
                  <span className={`w-1.5 h-1.5 rounded-full ${getStatusColor(employee.status)}`} />
                  {employee.status}
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-neutral-500 dark:text-neutral-400 mt-0.5 line-clamp-2">
                {employee.role} · {employee.department} · {employee.employmentType}
              </p>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-0.5 sm:gap-2">
            <button
              onClick={() => onEdit(employee)}
              className="p-1.5 text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-100 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              title="Edit Profile"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => onDelete(employee)}
              className="p-1.5 text-neutral-500 hover:text-red-600 dark:hover:text-red-400 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              title="Delete Profile"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="px-4 sm:px-6 border-b border-neutral-200 dark:border-neutral-800 flex gap-4 text-xs overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('overview')}
            className={`shrink-0 whitespace-nowrap py-2.5 font-medium border-b-2 -mb-[1px] transition-colors ${
              activeTab === 'overview'
                ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white'
                : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-300'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('compensation')}
            className={`shrink-0 whitespace-nowrap py-2.5 font-medium border-b-2 -mb-[1px] transition-colors ${
              activeTab === 'compensation'
                ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white'
                : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-300'
            }`}
          >
            <span className="sm:hidden">Compensation</span>
            <span className="hidden sm:inline">Compensation & Payroll</span>
          </button>
          <button
            onClick={() => setActiveTab('leave')}
            className={`shrink-0 whitespace-nowrap py-2.5 font-medium border-b-2 -mb-[1px] transition-colors ${
              activeTab === 'leave'
                ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white'
                : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-300'
            }`}
          >
            <span className="sm:hidden">Leaves</span>
            <span className="hidden sm:inline">Leaves & Attendance</span>
          </button>
          <button
            onClick={() => setActiveTab('emergency')}
            className={`shrink-0 whitespace-nowrap py-2.5 font-medium border-b-2 -mb-[1px] transition-colors ${
              activeTab === 'emergency'
                ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white'
                : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-300'
            }`}
          >
            <span className="sm:hidden">Emergency</span>
            <span className="hidden sm:inline">Emergency & Notes</span>
          </button>
        </div>

        {/* Body content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 sm:space-y-5 text-xs text-neutral-700 dark:text-neutral-300 flex-1">
          {activeTab === 'overview' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4">
                <div className="space-y-1">
                  <span className="text-[11px] text-neutral-400 block">Work Email</span>
                  <div className="flex items-center gap-2 font-medium">
                    <Mail className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{employee.email}</span>
                  </div>
                </div>
                <div className="space-y-1">
                  <span className="text-[11px] text-neutral-400 block">Phone Number</span>
                  <div className="flex items-center gap-2 font-medium font-mono tabular-nums">
                    <Phone className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{employee.phone}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800 sm:grid-cols-2 sm:gap-4">
                <div className="space-y-1">
                  <span className="text-[11px] text-neutral-400 block">Location & Mode</span>
                  <div className="flex items-center gap-2 font-medium">
                    <MapPin className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{employee.location} ({employee.workMode})</span>
                  </div>
                </div>
                <div className="space-y-1">
                  <span className="text-[11px] text-neutral-400 block">Reporting Manager</span>
                  <div className="flex items-center gap-2 font-medium">
                    <UserCheck className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{employee.manager}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800 sm:grid-cols-2 sm:gap-4">
                <div className="space-y-1">
                  <span className="text-[11px] text-neutral-400 block">Date of Joining</span>
                  <div className="flex items-center gap-2 font-medium font-mono tabular-nums">
                    <Calendar className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{employee.joinDate}</span>
                  </div>
                </div>
                <div className="space-y-1">
                  <span className="text-[11px] text-neutral-400 block">Employment Classification</span>
                  <div className="flex items-center gap-2 font-medium">
                    <Briefcase className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{employee.employmentType}</span>
                  </div>
                </div>
              </div>

              {/* Status quick switcher in overview */}
              <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <span className="text-[11px] text-neutral-400">Current Work Status:</span>
                <div className="flex flex-wrap items-center gap-1.5">
                  {(['Active', 'On Leave', 'Probation', 'Inactive'] as EmployeeStatus[]).map(st => (
                    <button
                      key={st}
                      onClick={() => updateEmployee(employee.id, { status: st })}
                      className={`px-2 py-1 text-[11px] font-medium rounded transition-colors ${
                        employee.status === st
                          ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                          : 'bg-neutral-100 text-neutral-600 dark:bg-neutral-800 dark:text-neutral-400 hover:bg-neutral-200 dark:hover:bg-neutral-700'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'compensation' && (
            <div className="space-y-4">
              {/* Annual CTC summary */}
              <div className="p-4 bg-neutral-50 dark:bg-neutral-800/60 rounded border border-neutral-200 dark:border-neutral-800 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">Annual Cost to Company (CTC)</span>
                  <span className="text-lg font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
                    {formatMoney(employee.salaryAnnual)}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">Monthly Gross</span>
                  <span className="text-sm font-semibold font-mono tabular-nums text-neutral-800 dark:text-neutral-200">
                    {formatMoney(monthlyGross)}
                  </span>
                </div>
              </div>

              {/* Monthly breakdown table */}
              <div className="border border-neutral-200 dark:border-neutral-800 rounded overflow-hidden">
                <div className="px-3 py-2 bg-neutral-100/70 dark:bg-neutral-800/80 font-medium text-[11px] text-neutral-600 dark:text-neutral-300">
                  Monthly Pay Breakdown
                </div>
                <div className="divide-y divide-neutral-100 dark:divide-neutral-800 text-xs">
                  <div className="flex items-center justify-between px-3 py-2">
                    <span className="text-neutral-600 dark:text-neutral-400">Basic Salary (50%)</span>
                    <span className="font-mono tabular-nums font-medium">{formatMoney(monthlyBase)}</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2">
                    <span className="text-neutral-600 dark:text-neutral-400">House Rent Allowance (HRA 30%)</span>
                    <span className="font-mono tabular-nums font-medium">{formatMoney(monthlyHra)}</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2">
                    <span className="text-neutral-600 dark:text-neutral-400">Special Allowances (20%)</span>
                    <span className="font-mono tabular-nums font-medium">{formatMoney(monthlyAllowances)}</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2 text-neutral-500">
                    <span>Provident Fund (PF - 12% of Basic)</span>
                    <span className="font-mono tabular-nums font-medium text-red-600 dark:text-red-400">- {formatMoney(monthlyPf)}</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2 text-neutral-500">
                    <span>Standard Tax Deduction (TDS Est.)</span>
                    <span className="font-mono tabular-nums font-medium text-red-600 dark:text-red-400">- {formatMoney(monthlyTax)}</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2.5 bg-neutral-50 dark:bg-neutral-800/40 font-semibold">
                    <span className="text-neutral-900 dark:text-neutral-100">Estimated Monthly Net Take-Home</span>
                    <span className="font-mono tabular-nums text-neutral-900 dark:text-neutral-100">{formatMoney(monthlyNet)}</span>
                  </div>
                </div>
              </div>

              {/* Bank Details */}
              <div className="p-3 border border-neutral-200 dark:border-neutral-800 rounded space-y-1">
                <span className="text-[11px] text-neutral-400 block">Bank Account for Payroll Disbursal</span>
                <div className="flex flex-col gap-1 font-mono tabular-nums text-xs sm:flex-row sm:items-center sm:justify-between">
                  <span>{employee.bankInfo.bankName} · {employee.bankInfo.accountMasked}</span>
                  <span className="text-neutral-500">{employee.bankInfo.ifscOrSwift}</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'leave' && (
            <div className="space-y-4">
              {/* Leave balances */}
              <div className="grid grid-cols-3 gap-2 sm:gap-3">
                <div className="p-2.5 sm:p-3 border border-neutral-200 dark:border-neutral-800 rounded bg-neutral-50 dark:bg-neutral-800/40">
                  <span className="text-[11px] text-neutral-400 block">Paid Annual</span>
                  <span className="text-lg font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
                    {employee.leaveBalance.annual}
                  </span>
                  <span className="text-[10px] text-neutral-500 block">days remaining</span>
                </div>
                <div className="p-2.5 sm:p-3 border border-neutral-200 dark:border-neutral-800 rounded bg-neutral-50 dark:bg-neutral-800/40">
                  <span className="text-[11px] text-neutral-400 block">Casual Leave</span>
                  <span className="text-lg font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
                    {employee.leaveBalance.casual}
                  </span>
                  <span className="text-[10px] text-neutral-500 block">days remaining</span>
                </div>
                <div className="p-2.5 sm:p-3 border border-neutral-200 dark:border-neutral-800 rounded bg-neutral-50 dark:bg-neutral-800/40">
                  <span className="text-[11px] text-neutral-400 block">Sick / Medical</span>
                  <span className="text-lg font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
                    {employee.leaveBalance.sick}
                  </span>
                  <span className="text-[10px] text-neutral-500 block">days remaining</span>
                </div>
              </div>

              {/* Leave applications for this employee */}
              <div>
                <span className="text-[11px] font-semibold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider block mb-2">
                  Leave Application History
                </span>
                {empLeaves.length === 0 ? (
                  <p className="text-neutral-400 text-xs">No leave requests recorded for this staff member.</p>
                ) : (
                  <div className="border border-neutral-200 dark:border-neutral-800 rounded divide-y divide-neutral-100 dark:divide-neutral-800">
                    {empLeaves.map(lv => (
                      <div key={lv.id} className="p-2.5 flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between text-xs">
                        <div>
                          <div className="font-medium text-neutral-800 dark:text-neutral-200">
                            {lv.type} Leave ({lv.days} {lv.days === 1 ? 'day' : 'days'})
                          </div>
                          <div className="text-[11px] text-neutral-400 font-mono tabular-nums">
                            {lv.startDate} to {lv.endDate} · &quot;{lv.reason}&quot;
                          </div>
                        </div>
                        <span className="text-xs font-medium text-neutral-700 dark:text-neutral-300">
                          {lv.status}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'emergency' && (
            <div className="space-y-4">
              <div className="p-4 border border-neutral-200 dark:border-neutral-800 rounded space-y-2">
                <span className="text-[11px] text-neutral-400 font-medium uppercase tracking-wider block">
                  Primary Emergency Contact
                </span>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-neutral-900 dark:text-neutral-100">
                    {employee.emergencyContact.name}
                  </span>
                  <span className="text-neutral-500 text-xs">
                    {employee.emergencyContact.relation}
                  </span>
                </div>
                <div className="flex items-center gap-2 font-mono tabular-nums text-xs text-neutral-700 dark:text-neutral-300">
                  <Phone className="w-3.5 h-3.5 text-neutral-400" />
                  <span>{employee.emergencyContact.phone}</span>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-[11px] text-neutral-400 block font-medium">HR & Manager Internal Notes</span>
                <div className="p-3 bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-800 rounded text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                  {employee.notes || 'No confidential notes filed for this employee.'}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-between bg-neutral-50/50 dark:bg-neutral-900/50">
          <span className="text-[11px] text-neutral-400 font-mono tabular-nums">
            ID: {employee.id}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 rounded-md hover:bg-neutral-800 dark:hover:bg-white transition-colors"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { X, Check } from 'lucide-react';
import { Employee, EmploymentType, WorkMode, EmployeeStatus } from '../../types/employee';
import { useEmployees } from '../../context/EmployeeContext';

interface EmployeeFormModalProps {
  employee?: Employee | null;
  isOpen: boolean;
  onClose: () => void;
}

export const EmployeeFormModal: React.FC<EmployeeFormModalProps> = ({
  employee,
  isOpen,
  onClose
}) => {
  const { departments, addEmployee, updateEmployee, currency } = useEmployees();

  const isEditing = !!employee;

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    role: '',
    department: 'Engineering',
    employmentType: 'Full-time' as EmploymentType,
    workMode: 'Hybrid' as WorkMode,
    status: 'Active' as EmployeeStatus,
    joinDate: new Date().toISOString().split('T')[0],
    salaryAnnual: 1800000,
    location: 'Bengaluru, India',
    manager: 'CEO / Board',
    emergencyContactName: '',
    emergencyContactRelation: 'Spouse',
    emergencyContactPhone: '',
    bankName: 'HDFC Bank',
    accountNumber: '',
    ifscOrSwift: 'HDFC0001024',
    notes: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (employee) {
      setFormData({
        firstName: employee.firstName,
        lastName: employee.lastName,
        email: employee.email,
        phone: employee.phone,
        role: employee.role,
        department: employee.department,
        employmentType: employee.employmentType,
        workMode: employee.workMode,
        status: employee.status,
        joinDate: employee.joinDate,
        salaryAnnual: employee.salaryAnnual,
        location: employee.location,
        manager: employee.manager,
        emergencyContactName: employee.emergencyContact.name,
        emergencyContactRelation: employee.emergencyContact.relation,
        emergencyContactPhone: employee.emergencyContact.phone,
        bankName: employee.bankInfo.bankName,
        accountNumber: employee.bankInfo.accountMasked.replace(/[^\d]/g, '') || '4521',
        ifscOrSwift: employee.bankInfo.ifscOrSwift,
        notes: employee.notes || ''
      });
    } else {
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '+91 ',
        role: '',
        department: departments[0]?.name || 'Engineering',
        employmentType: 'Full-time',
        workMode: 'Hybrid',
        status: 'Active',
        joinDate: new Date().toISOString().split('T')[0],
        salaryAnnual: 1800000,
        location: 'Bengaluru, India',
        manager: 'Rohan Verma',
        emergencyContactName: '',
        emergencyContactRelation: 'Spouse',
        emergencyContactPhone: '+91 ',
        bankName: 'HDFC Bank',
        accountNumber: '4019',
        ifscOrSwift: 'HDFC0001042',
        notes: ''
      });
    }
    setErrors({});
  }, [employee, isOpen, departments]);

  if (!isOpen) return null;

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.firstName.trim()) newErrors.firstName = 'First name is required';
    if (!formData.lastName.trim()) newErrors.lastName = 'Last name is required';
    if (!formData.email.trim() || !formData.email.includes('@')) newErrors.email = 'Valid email is required';
    if (!formData.role.trim()) newErrors.role = 'Role title is required';
    if (!formData.salaryAnnual || formData.salaryAnnual <= 0) newErrors.salaryAnnual = 'Valid salary required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const payload = {
      firstName: formData.firstName.trim(),
      lastName: formData.lastName.trim(),
      email: formData.email.trim(),
      phone: formData.phone.trim(),
      role: formData.role.trim(),
      department: formData.department,
      employmentType: formData.employmentType,
      workMode: formData.workMode,
      status: formData.status,
      joinDate: formData.joinDate,
      salaryAnnual: Number(formData.salaryAnnual),
      location: formData.location.trim(),
      manager: formData.manager.trim(),
      emergencyContact: {
        name: formData.emergencyContactName.trim() || 'Not Provided',
        relation: formData.emergencyContactRelation,
        phone: formData.emergencyContactPhone.trim() || formData.phone.trim()
      },
      bankInfo: {
        accountMasked: `•••• •••• ${formData.accountNumber.slice(-4) || '9921'}`,
        bankName: formData.bankName,
        ifscOrSwift: formData.ifscOrSwift.trim()
      },
      leaveBalance: employee?.leaveBalance || { annual: 15, casual: 6, sick: 10 },
      notes: formData.notes.trim()
    };

    if (isEditing && employee) {
      updateEmployee(employee.id, payload);
    } else {
      addEmployee(payload);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-neutral-900/40 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div 
        className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-lg w-full max-w-2xl max-h-[92dvh] flex flex-col shadow-xl overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-4 sm:px-6 py-4 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
              {isEditing ? `Edit Employee (${employee?.employeeCode})` : 'Add New Employee'}
            </h2>
            <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
              {isEditing ? 'Update personnel details, role, and compensation.' : 'Enter personnel profile, department, and salary parameters.'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded transition-colors"
            aria-label="Close form"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs">
          {/* Row 1: Name */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4">
            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                First Name *
              </label>
              <input
                type="text"
                value={formData.firstName}
                onChange={e => setFormData({ ...formData, firstName: e.target.value })}
                placeholder="e.g. Rahul"
                className={`w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none ${
                  errors.firstName ? 'border-red-500' : 'border-neutral-200 dark:border-neutral-700'
                }`}
              />
              {errors.firstName && <span className="text-[10px] text-red-500 mt-0.5 block">{errors.firstName}</span>}
            </div>

            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Last Name *
              </label>
              <input
                type="text"
                value={formData.lastName}
                onChange={e => setFormData({ ...formData, lastName: e.target.value })}
                placeholder="e.g. Nair"
                className={`w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none ${
                  errors.lastName ? 'border-red-500' : 'border-neutral-200 dark:border-neutral-700'
                }`}
              />
              {errors.lastName && <span className="text-[10px] text-red-500 mt-0.5 block">{errors.lastName}</span>}
            </div>
          </div>

          {/* Row 2: Email & Phone */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4">
            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Work Email *
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                placeholder="rahul.nair@workbase.io"
                className={`w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none ${
                  errors.email ? 'border-red-500' : 'border-neutral-200 dark:border-neutral-700'
                }`}
              />
              {errors.email && <span className="text-[10px] text-red-500 mt-0.5 block">{errors.email}</span>}
            </div>

            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Phone Number
              </label>
              <input
                type="text"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+91 98765 43210"
                className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs font-mono tabular-nums text-neutral-900 dark:text-neutral-100 focus:outline-none"
              />
            </div>
          </div>

          {/* Row 3: Role & Department */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4">
            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Designation / Job Title *
              </label>
              <input
                type="text"
                value={formData.role}
                onChange={e => setFormData({ ...formData, role: e.target.value })}
                placeholder="e.g. Senior Software Engineer"
                className={`w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none ${
                  errors.role ? 'border-red-500' : 'border-neutral-200 dark:border-neutral-700'
                }`}
              />
              {errors.role && <span className="text-[10px] text-red-500 mt-0.5 block">{errors.role}</span>}
            </div>

            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Department
              </label>
              <select
                value={formData.department}
                onChange={e => setFormData({ ...formData, department: e.target.value })}
                className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
              >
                {departments.map(d => (
                  <option key={d.id} value={d.name}>{d.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Row 4: Classification, Work Mode, Status */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Employment Type
              </label>
              <select
                value={formData.employmentType}
                onChange={e => setFormData({ ...formData, employmentType: e.target.value as EmploymentType })}
                className="w-full px-2.5 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
              >
                <option value="Full-time">Full-time</option>
                <option value="Part-time">Part-time</option>
                <option value="Contract">Contract</option>
                <option value="Intern">Intern</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Work Mode
              </label>
              <select
                value={formData.workMode}
                onChange={e => setFormData({ ...formData, workMode: e.target.value as WorkMode })}
                className="w-full px-2.5 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
              >
                <option value="Hybrid">Hybrid</option>
                <option value="On-site">On-site</option>
                <option value="Remote">Remote</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Status
              </label>
              <select
                value={formData.status}
                onChange={e => setFormData({ ...formData, status: e.target.value as EmployeeStatus })}
                className="w-full px-2.5 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
              >
                <option value="Active">Active</option>
                <option value="On Leave">On Leave</option>
                <option value="Probation">Probation</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>

          {/* Row 5: Salary CTC & Joining Date */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4">
            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Annual CTC (in {currency === 'INR' ? '₹ INR' : '$ USD'}) *
              </label>
              <input
                type="number"
                value={formData.salaryAnnual}
                onChange={e => setFormData({ ...formData, salaryAnnual: Number(e.target.value) })}
                className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs font-mono tabular-nums text-neutral-900 dark:text-neutral-100 focus:outline-none"
              />
              <span className="text-[10px] text-neutral-400 mt-0.5 block">
                Monthly approx: ₹{Math.round(formData.salaryAnnual / 12).toLocaleString('en-IN')}
              </span>
            </div>

            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Joining Date
              </label>
              <input
                type="date"
                value={formData.joinDate}
                onChange={e => setFormData({ ...formData, joinDate: e.target.value })}
                className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs font-mono tabular-nums text-neutral-900 dark:text-neutral-100 focus:outline-none"
              />
            </div>
          </div>

          {/* Row 6: Location & Reporting Manager */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4">
            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Work Location / City
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={e => setFormData({ ...formData, location: e.target.value })}
                placeholder="Bengaluru, India"
                className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Reporting Manager
              </label>
              <input
                type="text"
                value={formData.manager}
                onChange={e => setFormData({ ...formData, manager: e.target.value })}
                placeholder="Rohan Verma"
                className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
              />
            </div>
          </div>

          {/* Row 7: Emergency Contact & Bank Info */}
          <div className="pt-2 border-t border-neutral-200 dark:border-neutral-800 space-y-3">
            <span className="text-[11px] font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider block">
              Emergency & Disbursal Information
            </span>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div>
                <label className="block text-[11px] text-neutral-500 mb-1">Contact Name</label>
                <input
                  type="text"
                  value={formData.emergencyContactName}
                  onChange={e => setFormData({ ...formData, emergencyContactName: e.target.value })}
                  placeholder="e.g. Ramesh Nair"
                  className="w-full px-2.5 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] text-neutral-500 mb-1">Relation</label>
                <input
                  type="text"
                  value={formData.emergencyContactRelation}
                  onChange={e => setFormData({ ...formData, emergencyContactRelation: e.target.value })}
                  placeholder="Parent / Spouse"
                  className="w-full px-2.5 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] text-neutral-500 mb-1">Contact Phone</label>
                <input
                  type="text"
                  value={formData.emergencyContactPhone}
                  onChange={e => setFormData({ ...formData, emergencyContactPhone: e.target.value })}
                  placeholder="+91 98..."
                  className="w-full px-2.5 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs font-mono tabular-nums text-neutral-900 dark:text-neutral-100 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div>
                <label className="block text-[11px] text-neutral-500 mb-1">Bank Name</label>
                <input
                  type="text"
                  value={formData.bankName}
                  onChange={e => setFormData({ ...formData, bankName: e.target.value })}
                  placeholder="HDFC Bank"
                  className="w-full px-2.5 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] text-neutral-500 mb-1">Account No (Last digits)</label>
                <input
                  type="text"
                  value={formData.accountNumber}
                  onChange={e => setFormData({ ...formData, accountNumber: e.target.value })}
                  placeholder="4092"
                  className="w-full px-2.5 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs font-mono tabular-nums text-neutral-900 dark:text-neutral-100 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] text-neutral-500 mb-1">IFSC / Routing</label>
                <input
                  type="text"
                  value={formData.ifscOrSwift}
                  onChange={e => setFormData({ ...formData, ifscOrSwift: e.target.value })}
                  placeholder="HDFC0001042"
                  className="w-full px-2.5 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs font-mono tabular-nums text-neutral-900 dark:text-neutral-100 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Row 8: Notes */}
          <div>
            <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
              Internal HR Notes
            </label>
            <textarea
              rows={2}
              value={formData.notes}
              onChange={e => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Candidate onboarding notes, special arrangements, key strengths..."
              className="w-full px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none"
            />
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 rounded text-xs font-medium text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 transition-colors"
            >
              {isEditing ? 'Save Changes' : 'Create Employee Record'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

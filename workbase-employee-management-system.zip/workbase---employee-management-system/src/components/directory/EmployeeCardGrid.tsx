import React from 'react';
import { Eye, Edit3, Trash2, Mail, Phone, MapPin } from 'lucide-react';
import { Employee } from '../../types/employee';
import { useEmployees } from '../../context/EmployeeContext';

interface EmployeeCardGridProps {
  employees: Employee[];
  onSelectEmployee: (emp: Employee) => void;
  onEditEmployee: (emp: Employee) => void;
  onDeleteEmployee: (emp: Employee) => void;
}

export const EmployeeCardGrid: React.FC<EmployeeCardGridProps> = ({
  employees,
  onSelectEmployee,
  onEditEmployee,
  onDeleteEmployee
}) => {
  const { formatMoney } = useEmployees();

  const getInitials = (first: string, last: string) => {
    return `${first.charAt(0)}${last.charAt(0)}`.toUpperCase();
  };

  const getStatusIndicator = (status: Employee['status']) => {
    switch (status) {
      case 'Active':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-neutral-700 dark:text-neutral-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            Active
          </span>
        );
      case 'On Leave':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-neutral-700 dark:text-neutral-300">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            On Leave
          </span>
        );
      case 'Probation':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-neutral-700 dark:text-neutral-300">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-500" />
            Probation
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-neutral-400">
            <span className="w-1.5 h-1.5 rounded-full bg-neutral-400" />
            Inactive
          </span>
        );
    }
  };

  if (employees.length === 0) {
    return (
      <div className="py-16 text-center text-xs text-neutral-400 dark:text-neutral-500">
        No employees found matching the filters.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-3 p-4 sm:grid-cols-2 sm:gap-4 sm:p-6 lg:grid-cols-3 xl:grid-cols-4">
      {employees.map(emp => (
        <div
          key={emp.id}
          onClick={() => onSelectEmployee(emp)}
          className="border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 rounded-lg p-4 flex flex-col justify-between hover:border-neutral-300 dark:hover:border-neutral-700 transition-all cursor-pointer group"
        >
          <div>
            {/* Header: Avatar, Name, Code, and Status */}
            <div className="flex items-start justify-between gap-3 mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 flex items-center justify-center font-medium text-xs shrink-0">
                  {getInitials(emp.firstName, emp.lastName)}
                </div>
                <div>
                  <h3 className="font-medium text-xs text-neutral-900 dark:text-neutral-100 group-hover:text-neutral-700 dark:group-hover:text-neutral-300 transition-colors">
                    {emp.firstName} {emp.lastName}
                  </h3>
                  <span className="font-mono tabular-nums text-[10px] text-neutral-400 dark:text-neutral-500">
                    {emp.employeeCode}
                  </span>
                </div>
              </div>
              <div className="shrink-0">{getStatusIndicator(emp.status)}</div>
            </div>

            {/* Role & Department */}
            <div className="mb-3">
              <p className="text-xs font-medium text-neutral-800 dark:text-neutral-200 truncate">
                {emp.role}
              </p>
              <div className="text-[11px] text-neutral-500 dark:text-neutral-400 flex items-center gap-1.5 mt-0.5">
                <span>{emp.department}</span>
                <span aria-hidden="true">·</span>
                <span>{emp.employmentType}</span>
              </div>
            </div>

            {/* Contact details */}
            <div className="space-y-1 text-[11px] text-neutral-500 dark:text-neutral-400 mb-3 border-t border-neutral-100 dark:border-neutral-800/80 pt-2.5">
              <div className="flex items-center gap-2 truncate">
                <Mail className="w-3 h-3 text-neutral-400 shrink-0" />
                <span className="truncate">{emp.email}</span>
              </div>
              <div className="flex items-center gap-2 truncate">
                <MapPin className="w-3 h-3 text-neutral-400 shrink-0" />
                <span className="truncate">{emp.location} ({emp.workMode})</span>
              </div>
            </div>
          </div>

          {/* Footer: Salary & Actions */}
          <div className="border-t border-neutral-100 dark:border-neutral-800 pt-3 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-neutral-400 uppercase tracking-wider block">
                Annual CTC
              </span>
              <span className="text-xs font-mono tabular-nums font-semibold text-neutral-900 dark:text-neutral-100">
                {formatMoney(emp.salaryAnnual)}
              </span>
            </div>

            <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
              <button
                onClick={() => onSelectEmployee(emp)}
                className="p-1 text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-200 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                title="View Profile"
              >
                <Eye className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onEditEmployee(emp)}
                className="p-1 text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-200 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                title="Edit Details"
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onDeleteEmployee(emp)}
                className="p-1 text-neutral-400 hover:text-red-600 dark:hover:text-red-400 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                title="Delete"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

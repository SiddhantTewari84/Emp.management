import React from 'react';
import { 
  MoreHorizontal, 
  Eye, 
  Edit3, 
  Trash2, 
  MapPin, 
  ArrowUpDown,
  Mail,
  Phone
} from 'lucide-react';
import { Employee, EmployeeStatus } from '../../types/employee';
import { useEmployees } from '../../context/EmployeeContext';

interface EmployeeTableProps {
  employees: Employee[];
  onSelectEmployee: (emp: Employee) => void;
  onEditEmployee: (emp: Employee) => void;
  onDeleteEmployee: (emp: Employee) => void;
  sortField: keyof Employee;
  sortDirection: 'asc' | 'desc';
  onToggleSort: (field: keyof Employee) => void;
}

export const EmployeeTable: React.FC<EmployeeTableProps> = ({
  employees,
  onSelectEmployee,
  onEditEmployee,
  onDeleteEmployee,
  sortField,
  sortDirection,
  onToggleSort
}) => {
  const { formatMoney, updateEmployee } = useEmployees();

  const getStatusIndicator = (status: EmployeeStatus) => {
    switch (status) {
      case 'Active':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-neutral-700 dark:text-neutral-300 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            Active
          </span>
        );
      case 'On Leave':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-neutral-700 dark:text-neutral-300 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            On Leave
          </span>
        );
      case 'Probation':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-neutral-700 dark:text-neutral-300 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-500" />
            Probation
          </span>
        );
      case 'Inactive':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-neutral-400 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-neutral-400" />
            Inactive
          </span>
        );
    }
  };

  const getInitials = (first: string, last: string) => {
    return `${first.charAt(0)}${last.charAt(0)}`.toUpperCase();
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[840px] text-left text-xs border-collapse">
        <thead>
          <tr className="border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50/75 dark:bg-neutral-900/50 text-neutral-500 dark:text-neutral-400 select-none">
            <th className="py-2.5 px-4 font-medium text-left">
              <button
                onClick={() => onToggleSort('firstName')}
                className="inline-flex items-center gap-1 hover:text-neutral-900 dark:hover:text-neutral-100"
              >
                <span>Employee</span>
                <ArrowUpDown className="w-3 h-3 text-neutral-400" />
              </button>
            </th>
            <th className="py-2.5 px-4 font-medium text-left">
              <button
                onClick={() => onToggleSort('role')}
                className="inline-flex items-center gap-1 hover:text-neutral-900 dark:hover:text-neutral-100"
              >
                <span>Role & Department</span>
                <ArrowUpDown className="w-3 h-3 text-neutral-400" />
              </button>
            </th>
            <th className="py-2.5 px-4 font-medium text-left">Work Mode</th>
            <th className="py-2.5 px-4 font-medium text-left">Status</th>
            <th className="py-2.5 px-4 font-medium text-left">
              <button
                onClick={() => onToggleSort('joinDate')}
                className="inline-flex items-center gap-1 hover:text-neutral-900 dark:hover:text-neutral-100"
              >
                <span>Join Date</span>
                <ArrowUpDown className="w-3 h-3 text-neutral-400" />
              </button>
            </th>
            <th className="py-2.5 px-4 font-medium text-right">
              <button
                onClick={() => onToggleSort('salaryAnnual')}
                className="inline-flex items-center justify-end gap-1 w-full hover:text-neutral-900 dark:hover:text-neutral-100"
              >
                <span>Annual CTC</span>
                <ArrowUpDown className="w-3 h-3 text-neutral-400" />
              </button>
            </th>
            <th className="py-2.5 px-4 font-medium text-right w-24">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-neutral-200/70 dark:divide-neutral-800/70">
          {employees.length === 0 ? (
            <tr>
              <td colSpan={7} className="py-12 text-center text-neutral-400 dark:text-neutral-500">
                No employees found matching the selected filters.
              </td>
            </tr>
          ) : (
            employees.map(emp => (
              <tr
                key={emp.id}
                className="hover:bg-neutral-50/80 dark:hover:bg-neutral-800/40 transition-colors group cursor-pointer"
                onClick={() => onSelectEmployee(emp)}
              >
                {/* Employee Name + ID + Email */}
                <td className="py-3 px-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-200 flex items-center justify-center font-medium text-xs shrink-0">
                      {getInitials(emp.firstName, emp.lastName)}
                    </div>
                    <div className="flex flex-col min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-medium text-neutral-900 dark:text-neutral-100 truncate">
                          {emp.firstName} {emp.lastName}
                        </span>
                        <span className="text-[10px] font-mono tabular-nums text-neutral-400 dark:text-neutral-500 shrink-0">
                          {emp.employeeCode}
                        </span>
                      </div>
                      <span className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">
                        {emp.email}
                      </span>
                    </div>
                  </div>
                </td>

                {/* Role & Department */}
                <td className="py-3 px-4">
                  <div className="flex flex-col">
                    <span className="font-medium text-neutral-800 dark:text-neutral-200">
                      {emp.role}
                    </span>
                    <span className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      {emp.department} · {emp.employmentType}
                    </span>
                  </div>
                </td>

                {/* Work Mode */}
                <td className="py-3 px-4">
                  <div className="flex flex-col">
                    <span className="text-neutral-700 dark:text-neutral-300 font-medium">
                      {emp.workMode}
                    </span>
                    <span className="text-[11px] text-neutral-400 truncate">
                      {emp.location}
                    </span>
                  </div>
                </td>

                {/* Status with quick toggle click */}
                <td className="py-3 px-4" onClick={e => e.stopPropagation()}>
                  <div className="relative inline-block group/status">
                    {getStatusIndicator(emp.status)}
                    {/* Quick status dropdown */}
                    <select
                      value={emp.status}
                      onChange={e => updateEmployee(emp.id, { status: e.target.value as EmployeeStatus })}
                      className="absolute inset-0 opacity-0 cursor-pointer w-full"
                      title="Change status"
                    >
                      <option value="Active">Active</option>
                      <option value="On Leave">On Leave</option>
                      <option value="Probation">Probation</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                </td>

                {/* Join Date */}
                <td className="py-3 px-4 font-mono tabular-nums text-neutral-600 dark:text-neutral-400 text-xs">
                  {emp.joinDate}
                </td>

                {/* Salary */}
                <td className="py-3 px-4 font-mono tabular-nums text-right font-medium text-neutral-900 dark:text-neutral-100">
                  {formatMoney(emp.salaryAnnual)}
                </td>

                {/* Row Actions */}
                <td className="py-3 px-4 text-right" onClick={e => e.stopPropagation()}>
                  <div className="flex items-center justify-end gap-1">
                    <button
                      onClick={() => onSelectEmployee(emp)}
                      className="p-1 text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-100 rounded hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors"
                      title="View Profile"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onEditEmployee(emp)}
                      className="p-1 text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-100 rounded hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors"
                      title="Edit Employee"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onDeleteEmployee(emp)}
                      className="p-1 text-neutral-400 hover:text-red-600 dark:hover:text-red-400 rounded hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors"
                      title="Delete Record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

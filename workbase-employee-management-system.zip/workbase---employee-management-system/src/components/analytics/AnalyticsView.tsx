import React from 'react';
import { useEmployees } from '../../context/EmployeeContext';
import { Users, Building, Laptop, CalendarCheck, ShieldCheck } from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const { employees, departments, leaveRequests, formatMoney } = useEmployees();

  const totalHeadcount = employees.length;
  const activeCount = employees.filter(e => e.status === 'Active').length;
  const onLeaveCount = employees.filter(e => e.status === 'On Leave').length;
  const probationCount = employees.filter(e => e.status === 'Probation').length;

  const totalAnnualPayroll = employees.reduce((sum, e) => sum + e.salaryAnnual, 0);
  const avgAnnualSalary = totalHeadcount > 0 ? Math.round(totalAnnualPayroll / totalHeadcount) : 0;

  // Work mode ratios
  const hybridCount = employees.filter(e => e.workMode === 'Hybrid').length;
  const onsiteCount = employees.filter(e => e.workMode === 'On-site').length;
  const remoteCount = employees.filter(e => e.workMode === 'Remote').length;

  // Employment type breakdown
  const fullTimeCount = employees.filter(e => e.employmentType === 'Full-time').length;
  const contractCount = employees.filter(e => e.employmentType === 'Contract').length;
  const internCount = employees.filter(e => e.employmentType === 'Intern').length;
  const partTimeCount = employees.filter(e => e.employmentType === 'Part-time').length;

  // Department distribution
  const deptStats = departments.map(dept => {
    const members = employees.filter(e => e.department.toLowerCase() === dept.name.toLowerCase());
    const spend = members.reduce((sum, m) => sum + m.salaryAnnual, 0);
    const percentage = totalHeadcount > 0 ? Math.round((members.length / totalHeadcount) * 100) : 0;
    return {
      name: dept.name,
      code: dept.code,
      count: members.length,
      percentage,
      spend
    };
  }).sort((a, b) => b.count - a.count);

  return (
    <div className="flex-1 flex flex-col overflow-y-auto p-4 sm:p-6 space-y-4 sm:space-y-6">
      {/* Overview stats header */}
      <div>
        <h2 className="text-base font-semibold text-neutral-900 dark:text-neutral-100">
          Workforce & Headcount Metrics
        </h2>
        <p className="text-xs text-neutral-500 dark:text-neutral-400">
          Real-time organizational telemetry across departments, contracts, and compensation.
        </p>
      </div>

      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-3 sm:p-4 border border-neutral-200 dark:border-neutral-800 rounded-lg bg-white dark:bg-neutral-900">
          <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block mb-1">Total Headcount</span>
          <div className="flex items-baseline justify-between">
            <span className="text-xl sm:text-2xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {totalHeadcount}
            </span>
            <span className="text-xs text-neutral-500 font-mono tabular-nums">
              {activeCount} active
            </span>
          </div>
        </div>

        <div className="p-3 sm:p-4 border border-neutral-200 dark:border-neutral-800 rounded-lg bg-white dark:bg-neutral-900">
          <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block mb-1">Annual Payroll Outlay</span>
          <div className="flex items-baseline justify-between">
            <span className="text-base sm:text-xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {formatMoney(totalAnnualPayroll)}
            </span>
          </div>
        </div>

        <div className="p-3 sm:p-4 border border-neutral-200 dark:border-neutral-800 rounded-lg bg-white dark:bg-neutral-900">
          <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block mb-1">Average Compensation</span>
          <div className="flex items-baseline justify-between">
            <span className="text-base sm:text-xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {formatMoney(avgAnnualSalary)}
            </span>
            <span className="text-xs text-neutral-400">/ yr</span>
          </div>
        </div>

        <div className="p-3 sm:p-4 border border-neutral-200 dark:border-neutral-800 rounded-lg bg-white dark:bg-neutral-900">
          <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block mb-1">Staff Under Probation</span>
          <div className="flex items-baseline justify-between">
            <span className="text-xl sm:text-2xl font-bold font-mono tabular-nums text-sky-600 dark:text-sky-400">
              {probationCount}
            </span>
            <span className="text-xs text-neutral-400">90-day review</span>
          </div>
        </div>
      </div>

      {/* Two columns: Department Distribution & Work Mode Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Headcount Breakdown */}
        <div className="p-5 border border-neutral-200 dark:border-neutral-800 rounded-lg bg-white dark:bg-neutral-900">
          <h3 className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider mb-4">
            Department Headcount Distribution
          </h3>
          <div className="space-y-3 text-xs">
            {deptStats.map(dept => (
              <div key={dept.name}>
                <div className="mb-1 flex flex-col gap-0.5 sm:flex-row sm:items-center sm:justify-between sm:gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-neutral-800 dark:text-neutral-200">{dept.name}</span>
                    <span className="text-[10px] font-mono text-neutral-400">({dept.code})</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 font-mono tabular-nums text-neutral-600 dark:text-neutral-400 sm:gap-3">
                    <span>{dept.count} staff ({dept.percentage}%)</span>
                    <span className="text-neutral-400">·</span>
                    <span className="font-medium text-neutral-800 dark:text-neutral-200">{formatMoney(dept.spend)}</span>
                  </div>
                </div>
                {/* Clean horizontal meter bar */}
                <div className="w-full h-1.5 bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-neutral-800 dark:bg-neutral-200 rounded-full"
                    style={{ width: `${Math.max(dept.percentage, 4)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Work Mode & Classification Split */}
        <div className="space-y-6">
          {/* Work Mode */}
          <div className="p-5 border border-neutral-200 dark:border-neutral-800 rounded-lg bg-white dark:bg-neutral-900">
            <h3 className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider mb-4">
              Work Location & Modality
            </h3>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-3 border border-neutral-100 dark:border-neutral-800 rounded bg-neutral-50/50 dark:bg-neutral-800/40">
                <span className="text-[11px] text-neutral-500 block mb-1">Hybrid</span>
                <span className="text-xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
                  {hybridCount}
                </span>
                <span className="text-[10px] text-neutral-400 block mt-0.5">
                  {totalHeadcount > 0 ? Math.round((hybridCount / totalHeadcount) * 100) : 0}% of workforce
                </span>
              </div>

              <div className="p-3 border border-neutral-100 dark:border-neutral-800 rounded bg-neutral-50/50 dark:bg-neutral-800/40">
                <span className="text-[11px] text-neutral-500 block mb-1">On-site</span>
                <span className="text-xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
                  {onsiteCount}
                </span>
                <span className="text-[10px] text-neutral-400 block mt-0.5">
                  {totalHeadcount > 0 ? Math.round((onsiteCount / totalHeadcount) * 100) : 0}% of workforce
                </span>
              </div>

              <div className="p-3 border border-neutral-100 dark:border-neutral-800 rounded bg-neutral-50/50 dark:bg-neutral-800/40">
                <span className="text-[11px] text-neutral-500 block mb-1">Remote</span>
                <span className="text-xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
                  {remoteCount}
                </span>
                <span className="text-[10px] text-neutral-400 block mt-0.5">
                  {totalHeadcount > 0 ? Math.round((remoteCount / totalHeadcount) * 100) : 0}% of workforce
                </span>
              </div>
            </div>
          </div>

          {/* Employment Type Split */}
          <div className="p-5 border border-neutral-200 dark:border-neutral-800 rounded-lg bg-white dark:bg-neutral-900">
            <h3 className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider mb-4">
              Contract & Employment Types
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
              <div className="p-2 border border-neutral-100 dark:border-neutral-800 rounded text-center">
                <span className="text-[10px] text-neutral-400 block">Full-time</span>
                <span className="font-mono tabular-nums font-bold text-sm text-neutral-900 dark:text-neutral-100">
                  {fullTimeCount}
                </span>
              </div>
              <div className="p-2 border border-neutral-100 dark:border-neutral-800 rounded text-center">
                <span className="text-[10px] text-neutral-400 block">Contract</span>
                <span className="font-mono tabular-nums font-bold text-sm text-neutral-900 dark:text-neutral-100">
                  {contractCount}
                </span>
              </div>
              <div className="p-2 border border-neutral-100 dark:border-neutral-800 rounded text-center">
                <span className="text-[10px] text-neutral-400 block">Intern</span>
                <span className="font-mono tabular-nums font-bold text-sm text-neutral-900 dark:text-neutral-100">
                  {internCount}
                </span>
              </div>
              <div className="p-2 border border-neutral-100 dark:border-neutral-800 rounded text-center">
                <span className="text-[10px] text-neutral-400 block">Part-time</span>
                <span className="font-mono tabular-nums font-bold text-sm text-neutral-900 dark:text-neutral-100">
                  {partTimeCount}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Employee, 
  Department, 
  LeaveRequest, 
  AttendanceRecord, 
  PayrollRecord,
  AttendanceStatus,
  LeaveStatus 
} from '../types/employee';
import { 
  INITIAL_EMPLOYEES, 
  INITIAL_DEPARTMENTS, 
  INITIAL_LEAVE_REQUESTS, 
  INITIAL_ATTENDANCE,
  generatePayrollRecords 
} from '../data/mockData';

interface EmployeeContextType {
  employees: Employee[];
  departments: Department[];
  leaveRequests: LeaveRequest[];
  attendance: AttendanceRecord[];
  payroll: PayrollRecord[];
  currency: 'INR' | 'USD';
  setCurrency: (currency: 'INR' | 'USD') => void;
  formatMoney: (amountInINR: number) => string;
  addEmployee: (emp: Omit<Employee, 'id' | 'employeeCode'>) => Employee;
  updateEmployee: (id: string, emp: Partial<Employee>) => void;
  deleteEmployee: (id: string) => void;
  applyLeave: (leave: Omit<LeaveRequest, 'id' | 'status' | 'appliedDate'>) => void;
  updateLeaveStatus: (id: string, status: LeaveStatus, reviewer?: string) => void;
  markAttendance: (employeeId: string, status: AttendanceStatus, checkIn?: string, checkOut?: string) => void;
  addDepartment: (dept: Omit<Department, 'id'>) => void;
  updatePayrollStatus: (id: string, status: 'Paid' | 'Pending' | 'Processing') => void;
  runBatchPayroll: (month: string) => void;
  resetToDefaultData: () => void;
  exportEmployeesCSV: () => void;
}

const STORAGE_KEY_PREFIX = 'workbase_ems_v2_';

const EmployeeContext = createContext<EmployeeContextType | undefined>(undefined);

export const EmployeeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currency, setCurrency] = useState<'INR' | 'USD'>('INR');

  const [employees, setEmployees] = useState<Employee[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}employees`);
      return saved ? JSON.parse(saved) : INITIAL_EMPLOYEES;
    } catch {
      return INITIAL_EMPLOYEES;
    }
  });

  const [departments, setDepartments] = useState<Department[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}departments`);
      return saved ? JSON.parse(saved) : INITIAL_DEPARTMENTS;
    } catch {
      return INITIAL_DEPARTMENTS;
    }
  });

  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}leaves`);
      return saved ? JSON.parse(saved) : INITIAL_LEAVE_REQUESTS;
    } catch {
      return INITIAL_LEAVE_REQUESTS;
    }
  });

  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}attendance`);
      return saved ? JSON.parse(saved) : INITIAL_ATTENDANCE;
    } catch {
      return INITIAL_ATTENDANCE;
    }
  });

  const [payroll, setPayroll] = useState<PayrollRecord[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}payroll`);
      return saved ? JSON.parse(saved) : generatePayrollRecords(INITIAL_EMPLOYEES);
    } catch {
      return generatePayrollRecords(INITIAL_EMPLOYEES);
    }
  });

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}employees`, JSON.stringify(employees));
    } catch (e) {
      console.error(e);
    }
  }, [employees]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}departments`, JSON.stringify(departments));
    } catch (e) {
      console.error(e);
    }
  }, [departments]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}leaves`, JSON.stringify(leaveRequests));
    } catch (e) {
      console.error(e);
    }
  }, [leaveRequests]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}attendance`, JSON.stringify(attendance));
    } catch (e) {
      console.error(e);
    }
  }, [attendance]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}payroll`, JSON.stringify(payroll));
    } catch (e) {
      console.error(e);
    }
  }, [payroll]);

  const formatMoney = (amountInINR: number): string => {
    if (currency === 'USD') {
      const inUSD = Math.round(amountInINR / 83.5);
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        maximumFractionDigits: 0
      }).format(inUSD);
    }

    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amountInINR);
  };

  const addEmployee = (empData: Omit<Employee, 'id' | 'employeeCode'>): Employee => {
    // Generate code EMP-XXXX
    const nextNum = employees.length > 0 
      ? Math.max(...employees.map(e => parseInt(e.employeeCode.replace(/\D/g, '') || '1000', 10))) + 1
      : 1001;
    const employeeCode = `EMP-${nextNum}`;
    const newId = `emp-${nextNum}`;

    const newEmployee: Employee = {
      ...empData,
      id: newId,
      employeeCode,
    };

    setEmployees(prev => [newEmployee, ...prev]);

    // Also create initial attendance record
    const todayStr = new Date().toISOString().split('T')[0];
    const newAtt: AttendanceRecord = {
      id: `att-${newId}-${Date.now()}`,
      employeeId: newId,
      employeeName: `${newEmployee.firstName} ${newEmployee.lastName}`,
      date: todayStr,
      status: newEmployee.workMode === 'Remote' ? 'Remote' : 'Present',
      checkIn: '09:00 AM'
    };
    setAttendance(prev => [newAtt, ...prev]);

    // Create payroll entry
    const monthlyGross = Math.round(newEmployee.salaryAnnual / 12);
    const baseSalary = Math.round(monthlyGross * 0.50);
    const hra = Math.round(monthlyGross * 0.30);
    const allowances = Math.round(monthlyGross * 0.20);
    const deductions = Math.round(baseSalary * 0.12);
    const tax = Math.round(monthlyGross * 0.10);
    const netPay = monthlyGross - deductions - tax;

    const newPay: PayrollRecord = {
      id: `pay-${newId}-oct-2026`,
      employeeId: newId,
      employeeName: `${newEmployee.firstName} ${newEmployee.lastName}`,
      employeeCode,
      role: newEmployee.role,
      department: newEmployee.department,
      month: 'October 2026',
      baseSalary,
      hra,
      allowances,
      deductions,
      tax,
      netPay,
      status: 'Paid',
      paymentDate: '2026-10-01'
    };
    setPayroll(prev => [newPay, ...prev]);

    return newEmployee;
  };

  const updateEmployee = (id: string, updatedFields: Partial<Employee>) => {
    setEmployees(prev =>
      prev.map(emp => {
        if (emp.id === id) {
          const updated = { ...emp, ...updatedFields };
          // If name changed, reflect in payroll and attendance as well
          const fullName = `${updated.firstName} ${updated.lastName}`;
          setAttendance(attList =>
            attList.map(a => (a.employeeId === id ? { ...a, employeeName: fullName } : a))
          );
          setPayroll(payList =>
            payList.map(p => (p.employeeId === id ? { 
              ...p, 
              employeeName: fullName, 
              role: updated.role,
              department: updated.department,
              baseSalary: Math.round((updated.salaryAnnual / 12) * 0.5),
              netPay: Math.round((updated.salaryAnnual / 12) * 0.78)
            } : p))
          );
          return updated;
        }
        return emp;
      })
    );
  };

  const deleteEmployee = (id: string) => {
    setEmployees(prev => prev.filter(emp => emp.id !== id));
    setAttendance(prev => prev.filter(att => att.employeeId !== id));
    setLeaveRequests(prev => prev.filter(lv => lv.employeeId !== id));
    setPayroll(prev => prev.filter(p => p.employeeId !== id));
  };

  const applyLeave = (leaveData: Omit<LeaveRequest, 'id' | 'status' | 'appliedDate'>) => {
    const today = new Date().toISOString().split('T')[0];
    const newLeave: LeaveRequest = {
      ...leaveData,
      id: `lv-${Date.now()}`,
      status: 'Pending',
      appliedDate: today
    };
    setLeaveRequests(prev => [newLeave, ...prev]);
  };

  const updateLeaveStatus = (id: string, status: LeaveStatus, reviewer: string = 'Sunita Rao') => {
    setLeaveRequests(prev =>
      prev.map(item => {
        if (item.id === id) {
          const updated = { ...item, status, reviewedBy: reviewer };
          // If approved, update employee status and leave balance
          if (status === 'Approved') {
            setEmployees(empList =>
              empList.map(emp => {
                if (emp.id === item.employeeId) {
                  const balanceKey = item.type === 'Sick' ? 'sick' : item.type === 'Casual' ? 'casual' : 'annual';
                  const currentBal = emp.leaveBalance[balanceKey] || 0;
                  return {
                    ...emp,
                    status: 'On Leave',
                    leaveBalance: {
                      ...emp.leaveBalance,
                      [balanceKey]: Math.max(0, currentBal - item.days)
                    }
                  };
                }
                return emp;
              })
            );
            // Also update attendance for today
            setAttendance(attList =>
              attList.map(att =>
                att.employeeId === item.employeeId ? { ...att, status: 'On Leave' } : att
              )
            );
          }
          return updated;
        }
        return item;
      })
    );
  };

  const markAttendance = (
    employeeId: string, 
    status: AttendanceStatus, 
    checkIn?: string, 
    checkOut?: string
  ) => {
    const today = new Date().toISOString().split('T')[0];
    setAttendance(prev => {
      const existing = prev.find(a => a.employeeId === employeeId && a.date === today);
      if (existing) {
        return prev.map(a =>
          a.id === existing.id
            ? {
                ...a,
                status,
                checkIn: checkIn || a.checkIn || (status === 'Present' || status === 'Remote' ? '09:00 AM' : undefined),
                checkOut: checkOut || a.checkOut,
                workHours: status === 'Half Day' ? 4.5 : (status === 'Present' || status === 'Remote' ? 8.5 : 0)
              }
            : a
        );
      } else {
        const emp = employees.find(e => e.id === employeeId);
        const newRecord: AttendanceRecord = {
          id: `att-${employeeId}-${Date.now()}`,
          employeeId,
          employeeName: emp ? `${emp.firstName} ${emp.lastName}` : 'Employee',
          date: today,
          status,
          checkIn: checkIn || (status === 'Present' || status === 'Remote' ? '09:00 AM' : undefined),
          checkOut,
          workHours: status === 'Half Day' ? 4.5 : (status === 'Present' || status === 'Remote' ? 8.5 : 0)
        };
        return [newRecord, ...prev];
      }
    });
  };

  const addDepartment = (deptData: Omit<Department, 'id'>) => {
    const newDept: Department = {
      ...deptData,
      id: `dept-${deptData.code.toLowerCase()}-${Date.now()}`
    };
    setDepartments(prev => [...prev, newDept]);
  };

  const updatePayrollStatus = (id: string, status: 'Paid' | 'Pending' | 'Processing') => {
    setPayroll(prev =>
      prev.map(p => (p.id === id ? { ...p, status, paymentDate: status === 'Paid' ? new Date().toISOString().split('T')[0] : undefined } : p))
    );
  };

  const runBatchPayroll = (month: string) => {
    setPayroll(generatePayrollRecords(employees, month));
  };

  const resetToDefaultData = () => {
    setEmployees(INITIAL_EMPLOYEES);
    setDepartments(INITIAL_DEPARTMENTS);
    setLeaveRequests(INITIAL_LEAVE_REQUESTS);
    setAttendance(INITIAL_ATTENDANCE);
    setPayroll(generatePayrollRecords(INITIAL_EMPLOYEES));
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}employees`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}departments`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}leaves`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}attendance`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}payroll`);
  };

  const exportEmployeesCSV = () => {
    const headers = [
      'Employee ID',
      'First Name',
      'Last Name',
      'Email',
      'Phone',
      'Role',
      'Department',
      'Employment Type',
      'Work Mode',
      'Status',
      'Join Date',
      'Annual Salary',
      'Location',
      'Manager'
    ];

    const rows = employees.map(e => [
      e.employeeCode,
      `"${e.firstName}"`,
      `"${e.lastName}"`,
      `"${e.email}"`,
      `"${e.phone}"`,
      `"${e.role}"`,
      `"${e.department}"`,
      `"${e.employmentType}"`,
      `"${e.workMode}"`,
      `"${e.status}"`,
      e.joinDate,
      e.salaryAnnual,
      `"${e.location}"`,
      `"${e.manager}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `workbase_employees_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <EmployeeContext.Provider
      value={{
        employees,
        departments,
        leaveRequests,
        attendance,
        payroll,
        currency,
        setCurrency,
        formatMoney,
        addEmployee,
        updateEmployee,
        deleteEmployee,
        applyLeave,
        updateLeaveStatus,
        markAttendance,
        addDepartment,
        updatePayrollStatus,
        runBatchPayroll,
        resetToDefaultData,
        exportEmployeesCSV
      }}
    >
      {children}
    </EmployeeContext.Provider>
  );
};

export const useEmployees = () => {
  const context = useContext(EmployeeContext);
  if (!context) {
    throw new Error('useEmployees must be used within an EmployeeProvider');
  }
  return context;
};

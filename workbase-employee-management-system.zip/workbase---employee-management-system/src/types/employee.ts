export type EmploymentType = 'Full-time' | 'Part-time' | 'Contract' | 'Intern';
export type WorkMode = 'On-site' | 'Hybrid' | 'Remote';
export type EmployeeStatus = 'Active' | 'On Leave' | 'Probation' | 'Inactive';
export type LeaveType = 'Paid Annual' | 'Casual' | 'Sick' | 'Parental' | 'Unpaid';
export type LeaveStatus = 'Pending' | 'Approved' | 'Rejected';
export type AttendanceStatus = 'Present' | 'Remote' | 'On Leave' | 'Half Day' | 'Absent';

export interface EmergencyContact {
  name: string;
  relation: string;
  phone: string;
}

export interface BankInfo {
  accountMasked: string;
  bankName: string;
  ifscOrSwift: string;
}

export interface LeaveBalance {
  annual: number;
  casual: number;
  sick: number;
}

export interface Employee {
  id: string;
  employeeCode: string; // e.g. "EMP-1021"
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: string;
  department: string;
  employmentType: EmploymentType;
  workMode: WorkMode;
  status: EmployeeStatus;
  joinDate: string; // YYYY-MM-DD
  salaryAnnual: number;
  location: string;
  manager: string;
  emergencyContact: EmergencyContact;
  bankInfo: BankInfo;
  leaveBalance: LeaveBalance;
  notes?: string;
  avatarColor?: string; // subtle neutral tint for avatar badge
}

export interface Department {
  id: string;
  name: string;
  code: string;
  lead: string;
  budgetAnnual: number;
  description: string;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeRole: string;
  department: string;
  type: LeaveType;
  startDate: string;
  endDate: string;
  days: number;
  reason: string;
  status: LeaveStatus;
  appliedDate: string;
  reviewedBy?: string;
}

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string;
  status: AttendanceStatus;
  checkIn?: string;
  checkOut?: string;
  workHours?: number;
}

export interface PayrollRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  role: string;
  department: string;
  month: string; // e.g. "October 2026"
  baseSalary: number;
  hra: number;
  allowances: number;
  deductions: number;
  tax: number;
  netPay: number;
  status: 'Paid' | 'Pending' | 'Processing';
  paymentDate?: string;
}
